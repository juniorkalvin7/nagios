#! /usr/bin/env python
# -*- coding: utf-8 -*-

import commands,sys

saida = 0

comunity = ""
ip = ""
mib = ""
opcao = ""

args = sys.argv[1::]

if len(args) < 5:
  print "Ausencia de argumentos detectada. Favor digite no seguinte formato:"
  print "python %s ip comunity opcao warning critical descricao descricao"%sys.argv[0]
  print "python %s 10.0.0.42 u3fr0I9b5 cpu 80 90 none none "%sys.argv[0]
  print "python %s 10.0.0.42 u3fr0I9b5 memoria 80 90 none none "%sys.argv[0]
  print "python %s 10.0.0.42 u3fr0I9b5 mib 80 90 Descricao_Servico .1.3.6.1.4.1.2636.3.39.1.12.1.1.1.4  "%sys.argv[0]
  print "python %s 10.0.0.42 u3fr0I9b5 mib 80 90 Descricao_Servico .1.3.6.1.4.1.2636.3.39.1.12.1.1.1.4  unidade_de_medida "%sys.argv[0]
  print "Onde: \n-->   80 valor de alarme para WARNING"
  print "-->   90 valor de alarme para CRITICAL"  
  sys.exit(2)

try:
  ip = str(args[0])
  comunity =  str(args[1])
  opcao = str(args[2]).lower()
  warning= int(args[3])
  critical= int(args[4])
  descricao =  str(args[5]).replace(' ','_') 
  mib = str(args[6])
  unidade_de_medida = str(args[7])

except:
  warning= 80
  critical= 90

#print opcao
### cpu
if opcao == "cpu":
  mib = ".1.3.6.1.4.1.2636.3.39.1.12.1.1.1.4"
  con = commands.getoutput('snmpwalk -v1 -c %s %s %s'%(comunity,ip,mib))
  con = con.replace('SNMPv2-SMI::enterprises.2636.3.39.1.12.1.1.1.4.0 = Gauge32: ','')  

  if str(con).find("Timeout") != -1 or str(con).find("TIMEOUT") != -1:
          print "WARNING - Não foi possível realizar cominição via SNMP."
          saida = 1
  else:
          valor = int(con)

          if valor >=critical:
                  print "CRITICAL - Consumo atual de CPU: %s%% |Uso-CPU-Percet=%s"%(valor,valor)
                  saida = 2
          elif valor >=warning and valor < critical:
                  print "WARNING - Consumo atual de CPU: %s%% |Uso-CPU-Percet=%s"%(valor,valor) 
          else:
                  print "OK - Consumo atual de CPU: %s%% |Uso-CPU-Percet=%s"%(valor,valor)

### memoria
elif opcao == "memoria":
  mib = ".1.3.6.1.4.1.2636.3.39.1.12.1.1.1.5"
  con = commands.getoutput('snmpwalk -v1 -c %s %s %s'%(comunity,ip,mib)) 
  con = con.replace('SNMPv2-SMI::enterprises.2636.3.39.1.12.1.1.1.5.0 = Gauge32: ','')

  if str(con).find("Timeout") != -1 or str(con).find("TIMEOUT") != -1:
          print "WARNING - Não foi possível realizar cominição via SNMP."
          saida = 1
  else:
          valor = int(con)

          if valor >=critical:
                  print "CRITICAL - Consumo atual de Memoria: %s%% |Uso-Memoria-Percet=%s"%(valor,valor)
                  saida = 2
          elif valor >=warning and valor < critical:
                  print "WARNING - Consumo atual de Memoria: %s%% |Uso-Memoria-Percet=%s"%(valor,valor)      
                  saida = 1
          else:
                  print "OK - Consumo atual de Memoria: %s%% |Uso-Memoria-Percet=%s"%(valor,valor)       

### temperatura
elif opcao == "temperatura":
  mib = "1.3.6.1.4.1.2636.3.1.13.1.7.9.1.0.0"
  con = commands.getoutput('snmpwalk -v1 -c %s %s %s'%(comunity,ip,mib))
  con = str(con).split()[-1]
  
  if str(con).find("Timeout") != -1 or str(con).find("TIMEOUT") != -1:
          print "WARNING - Não foi possível realizar cominição via SNMP."
          saida = 1
  else:
          valor = int(con)

          if valor >=critical:
                  print "CRITICAL - Temepratura atual elevadíssima: %sC |temperatura-C=%s"%(valor,valor)
                  saida = 2
          elif valor >=warning and valor < critical:
                  print "WARNING - Temepratura atual elevada: %sC |temperatura-C=%s"%(valor,valor)      
                  saida = 1
          else:
                  print "OK - Temperatura atual dentro do esperado: %sC |temperatura-C=%s"%(valor,valor)

elif opcao == 'mib':
  con = commands.getoutput('snmpwalk -v1 -c %s %s %s'%(comunity,ip,mib))
  con = str(con).split()[-1]
  if str(con).find("Timeout") != -1 or str(con).find("TIMEOUT") != -1:
          print "WARNING - Não foi possível realizar cominição via SNMP."
          saida = 1
  else:
          valor = int(con)

          if valor >=critical:
            if unidade_de_medida == '%':
                  print "CRITICAL - %s: %s%% |%s=%s"%(descricao, valor,descricao,valor)
            else:
                  print "CRITICAL - %s: %s |%s=%s"%(descricao, valor,descricao,valor)
            if "uptime" not in descricao:
              saida = 2                  
          elif valor >=warning and valor < critical:
            if unidade_de_medida == '%': 
                  print "WARNING - %s: %s%% |%s=%s"%(descricao, valor,descricao,valor)
            else:      
                  print "WARNING - %s: %s |%s=%s"%(descricao, valor,descricao,valor)
            if "uptime" not in descricao:              
              saida = 1
          else:
            if unidade_de_medida == '%':                  
                  print "OK - %s: %s%% |%s=%s"%(descricao, valor,descricao,valor)
            else:
                  print "OK - %s: %s |%s=%s"%(descricao, valor,descricao,valor)

sys.exit(saida)


