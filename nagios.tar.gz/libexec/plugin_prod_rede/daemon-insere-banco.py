#! /usr/bin/env python
# ** coding:utf-8 **

from InsereBanco import MigraBanco

import sys, os, commands, re, time


caminho_pid = './pid_daemon_insere_banco'

try:
    pid = os.fork()
    #print 'PID do fork: ' + str(pid)
    if pid > 0:
        arq = open( caminho_pid ,'w')
        arq.write(str(pid))
        arq.close()
        print 'PID do fork: ' + str(pid)
        sys.exit(0)
    print "backgroundiando..."
except OSError, e:
    print >>sys.stderr, "fork #1 failed: %d (%s)" % (e.errno, e.strerror)
    sys.exit(1)
    
    
var_5min = 0

while 1:
    time.sleep(1)
    var_5min = var_5min + 1
    #if var_5min == 10*60:
    if var_5min == 13*60:
        
        #try:
            # CLIENTE 1 - NOME: INTECHNE - IP: 192.168.0.1
            # CLIENTE 3 - NOME: SESMA - IP: 192.168.0.10
	    # CLIENTE 4 - NOME: Maciel - IP: 10.10.10.34
        #mg = MigraBanco('nuvem','labsecur1t1','192.168.0.10','analise_rede')
        mg = MigraBanco('nuvem','labsecur1t1','10.10.10.34','analise_rede')
        mg.migrarBanco()
            
        #except:
        #print 'Erro na instanciacao.'
        var_5min = 0
