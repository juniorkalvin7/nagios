#!/usr/bin/env python
# -*- coding: UTF-8 -*- 


import MySQLdb
import sys, commands
from unicodedata import decomposition

class MigraBanco:

    user = ''
    passwd = ''
    host = ''
    db = ''
    con = None
    cur = None
    con_local = None
    cur_local = None

    def __init__(self, user,passwd,host,db):
        
        self.user = user
        self.passwd = passwd
        self.host = host
        self.db = db

    def conectarBancoLocal(self):
        #self.con_local = MySQLdb.connect(user="nuvem", passwd="labsecur1t1",host='cmp.intechne.com.br', db='analise_rede')
	self.con_local = MySQLdb.connect(user="nuvem", passwd="labsecur1t1",host='localhost', db='analise_rede')
    def conectarBanco(self):

        self.con = MySQLdb.connect(user=self.user, passwd=self.passwd,host=self.host, db=self.db)
#        print self.con
        #print self.con.cursor()
        self.cur = self.con.cursor()
    
    def commit(self):

        self.con.commit()
    
    def rollback(self):
        self.con.rollback()    
    
    def rollbackLocal(self):
        self.con_local.rollback()
    
    def commitBancoLocal(self):

        self.con_local.commit()
       
    def fecharConexao(self):
     
        self.con.close()

    def fecharConexaoLocal(self):
     
        self.con_local.close()
    
    def migrarBanco(self):

        self.conectarBanco()
        #self.cur.execute('SELECT * FROM analise_rede.TopQuantidadeBarrados;') 
        self.cur.execute('show tables;')
        tabelas = self.cur.fetchall()
        self.fecharConexao()
        for l in range(0,len(tabelas)-1):
            nome_tabela = tabelas[l][0]
            print "'%s'" %nome_tabela
            self.conectarBanco()

            self.cur.execute("SET lc_time_names = 'pt_BR';")
            self.cur.execute("SET NAMES 'UTF8';")

            self.cur.execute('SELECT * FROM %s;'%nome_tabela)
            lista = self.cur.fetchall()
            self.fecharConexao()
            self.direcionarInsercao(nome_tabela, lista)
        #    for l in lista:
        #       print l
        #    break
        #self.fecharConexao()
    
    #TopMaioresArquivosBaixados
    #TopQuantidadeBarrados
    #TopSitesBarrados
    #TopSitesBytes
    #TopSitesConexoes
    #TopTrafegoRede
    #TopUsuariosOnLine

    def direcionarInsercao(self, nome,tupla):

        if nome == 'TopMaioresArquivosBaixados':
            #print 'TopMaioresArquivosBaixados'
            #print len(tupla)
            self.inserirTopMaioresArquivosBaixados(tupla);
            
        elif nome == 'TopQuantidadeBarrados':
            #print 'TopQuantidadeBarrados'
            #print len(tupla)
            self.inserirTopQuantidadeBarrados(tupla);
            
        elif nome == 'TopSitesBarrados':
            #print 'TopSitesBarrados'
            #print len(tupla)
            self.inserirTopSitesBarrados(tupla);
            
        elif nome == 'TopSitesBytes':
            #print 'TopSitesBytes'
            #print len(tupla)
            self.inserirTopSitesBytes(tupla);
            
        elif nome == 'TopSitesConexoes':
            print 'TopSitesConexoes'
            print len(tupla)
            self.inserirTopSitesConexoes(tupla);
            
        elif nome == 'TopTrafegoRede':
            #print 'TopTrafegoRede'
            #print len(tupla)
            self.inserirTopTrafegoRede(tupla);
            
        elif nome == 'TopUsuariosOnLine':
            #print 'TopUsuariosOnLine'
            #print len(tupla)
            self.inserirTopUsuariosOnLine(tupla);

    def realizarMigracao(self,sql, tableName):
        problem = False
        # INSERINDO DADOS DO BANCO REMOTO NO BANCO DA NUVEM
        #try:
            #print
        self.conectarBancoLocal()
        #print 'len(parametros) %s'%len(parametros)
        self.cur_local = self.con_local.cursor()
        self.cur_local.execute('lock table %s Write;'%tableName)
            #self.cur_local.execute("SET lc_time_names = 'pt_BR';")
            #self.cur_local.execute("SET NAMES 'UTF8';")
        self.cur_local.execute(sql)
        self.commitBancoLocal()
        self.cur_local.execute('UNLOCK TABLES;')
        self.fecharConexaoLocal()
        print 'INSERINDO DADOS DO BANCO REMOTO NO BANCO DA NUVEM\n  everything  all right!'
        # break
        #for j in t:
        #       print j,
        #print
        #break
        #except:
        #    problem = True
        #    self.con.rollback()
        #    self.fecharConexaoLocal()
        #    print "FAIL, INSERINDO DADOS DO BANCO REMOTO NO BANCO DA NUVEM\n  wow, what's happening?"

        return problem
    
    def realizarDelecao(self,problem, tableName,horaInicio,horaFim):

        if problem == False:
        # Excluido dados do banco remoto que ja foram inseridos
            try:
                print ''' DELETE from %s where horaInsercao between '%s' and '%s' '''%(tableName,horaInicio,horaFim)
                self.conectarBanco()
                self.cur = self.con.cursor()
                self.cur.execute('lock table %s Write;'%tableName) 
                self.cur.execute(''' DELETE from %s where horaInsercao between '%s' and '%s' ;'''%(tableName,horaInicio,horaFim))
                self.commit()
                self.cur.execute('UNLOCK TABLES;')
                self.fecharConexao()
                print ' Excluido dados do banco remoto que ja foram inseridos\n  everything  all right!'
            except:
                self.con.rollback()
                self.fecharConexao()
                print "FAIL, Excluido dados do banco remoto que ja foram inseridos\n   wow, what's happening?"

    def inserirTopSitesConexoes(self, tupla):
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            parametros = t[1::]
            dominio = parametros[0]
            numAcessos = parametros[1]
            url1 = parametros[2].decode('utf-8')
            url2 = parametros[3].decode('utf-8')
            url3 = parametros[4].decode('utf-8')
            qtdAcesso1 = parametros[5]
            qtdAcesso2 = parametros[6]
            qtdAcesso3 = parametros[7]
            horaInsercao = parametros[8]
            Cliente_idCliente = parametros[9]
        #    for p in parametros:
        #       print '"%s" '%p

            #print parametros
            #print '''"%s", %s,"%s", "%s","%s", %s,%s, %s, '%s',%s'''%( dominio,  numAcessos, url1, url2, url3, qtdAcesso1, qtdAcesso2, qtdAcesso3, horaInsercao, Cliente_idCliente )
            sql = ''' INSERT INTO analise_rede.TopSitesConexoes ( dominio,  numAcessos, url1, url2, url3, qtdAcesso1, qtdAcesso2, qtdAcesso3, horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s,"%s", "%s","%s", %s,%s, %s, '%s',%s)'''%( dominio,  numAcessos, url1, url2, url3, qtdAcesso1, qtdAcesso2, qtdAcesso3, horaInsercao, Cliente_idCliente )
            print sql
            problem = self.realizarMigracao(sql, 'analise_rede.TopSitesConexoes')

        if len(tupla) > 0:
            horaInicio = tupla[0][9]
            horaFim = tupla[len(tupla)-1][9]
            self.realizarDelecao(problem, 'analise_rede.TopSitesConexoes',horaInicio,horaFim)

            
            


    def inserirTopMaioresArquivosBaixados(self,tupla):
        #analise_rede.TopMaioresArquivosBaixados
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            print t
            parametros = t[1::]
            urlArquivo = str(parametros[0])
            tamanhoArquivo = parametros[1]
            nomeUsuario = parametros[2]
            horaInsercao = parametros[3]
            Cliente_idCliente = parametros[4]
            
            if urlArquivo.find('\xc3') == -1:
                sql = """ INSERT INTO analise_rede.TopMaioresArquivosBaixados ( urlArquivo,  tamanhoArquivo, nomeUsuario, horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s, "%s", '%s',%s)"""%(urlArquivo,tamanhoArquivo,nomeUsuario,horaInsercao,Cliente_idCliente)
                print sql
                problem = self.realizarMigracao(sql, 'analise_rede.TopMaioresArquivosBaixados')

        if len(tupla) > 0:
            horaInicio = tupla[0][4]
            horaFim = tupla[len(tupla)-1][4]
            #print horaInicio,
            #print horaFim
            self.realizarDelecao(problem, 'analise_rede.TopMaioresArquivosBaixados',horaInicio,horaFim)    


    
    def inserirTopQuantidadeBarrados(self,tupla):
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            print t
            
            parametros = t[1::]
            
            numAcessosPermitidos = parametros[0]
            numAcessosNegados = parametros[1]
            horaInsercao = parametros[2]
            Cliente_idCliente = parametros[3]
            
            sql = """ INSERT INTO analise_rede.TopQuantidadeBarrados ( numAcessosPermitidos,  numAcessosNegados, horaInsercao, Cliente_idCliente ) VALUES ( %s, %s, '%s',%s)"""%(numAcessosPermitidos,numAcessosNegados,horaInsercao,Cliente_idCliente)
            print sql
            problem = self.realizarMigracao(sql, 'analise_rede.TopQuantidadeBarrados')

        if len(tupla) > 0:    
            horaInicio = tupla[0][3]
            horaFim = tupla[len(tupla)-1][3]
            #print horaInicio,
            #print horaFim
            self.realizarDelecao(problem, 'analise_rede.TopQuantidadeBarrados',horaInicio,horaFim)    
    
    def inserirTopSitesBarrados(self,tupla):
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            print t
            parametros = t[1::]
            
            url =  parametros[0]
            qtdAcessoNegado = parametros[1]
            horaInsercao = parametros[2]
            Cliente_idCliente = parametros[3]
                    
            sql = """ INSERT INTO  analise_rede.TopSitesBarrados( url, qtdAcessoNegado,  horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s, '%s',%s)"""%(url,qtdAcessoNegado,horaInsercao,Cliente_idCliente)
            print sql
            problem = self.realizarMigracao(sql, 'analise_rede.TopSitesBarrados')

        if len(tupla) > 0:    
            horaInicio = tupla[0][3]
            horaFim = tupla[len(tupla)-1][3]
            #print 'data'
            #print horaInicio,
            #print horaFim
            self.realizarDelecao(problem, 'analise_rede.TopSitesBarrados',horaInicio,horaFim)     
    
    def inserirTopSitesBytes(self,tupla):
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            print t
            parametros = t[1::]
            print 'len(parametros) %s'%len(parametros)
            url =  parametros[0]
            qtd = parametros[1]
            horaInsercao = parametros[2]
            Cliente_idCliente = parametros[3]
            
            sql = """ INSERT INTO analise_rede.TopSitesBytes ( url,  qtd, horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s, '%s',%s)"""%(url,qtd,horaInsercao,Cliente_idCliente)
            print sql
            problem = self.realizarMigracao(sql, 'analise_rede.TopSitesBytes')

        #print 'len(tupla[0]) %s'%len(tupla[0])
        #for t in tupla[0]:
        #    print t,
        if len(tupla) > 0:
            horaInicio = tupla[0][3]
            horaFim = tupla[len(tupla)-1][3]
            print horaInicio,
            print horaFim
            
            self.realizarDelecao(problem, 'analise_rede.TopSitesBytes',horaInicio,horaFim)     
           
    
    def inserirTopTrafegoRede(self,tupla):
        problem = False
        for t in tupla:
            print '%s ' %len(t)
            print t
            parametros = t[1::]
            print 'len(parametros) %s'%len(parametros)
            print 'tipo dado: %s'%parametros[0]
            
            #forcando mudanca para utf-8
            #tipoDado =  str(parametros[0]).decode('utf-8','ignore')
            tipoDado =  str(parametros[0].decode('utf-8'))
            tamanho = parametros[1]
            horaInsercao = parametros[2]
            Cliente_idCliente = parametros[3]
            
            print 'tipoDado %s'%tipoDado
            if tipoDado.find('+')==-1 and tipoDado.find('\xc3') == -1 and tipoDado.find('\xc5') == -1 and tipoDado.find('\x10') == -1 and tipoDado.find('\xc2') == -1 and tipoDado.find('\xe2') == -1 and tipoDado.find('\x10') == -1 and tipoDado.find('\xcb') == -1:
#           if True :
                sql = """ INSERT INTO analise_rede.TopTrafegoRede ( tipoDado,  tamanho, horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s, '%s',%s)"""%(tipoDado,tamanho,horaInsercao,Cliente_idCliente)
                print sql
                problem = self.realizarMigracao(sql, 'analise_rede.TopTrafegoRede')

        if len(tupla) > 0:
            horaInicio = tupla[0][3]
            horaFim = tupla[len(tupla)-1][3]
            print horaInicio,
            print horaFim
            
            self.realizarDelecao(problem, 'analise_rede.TopTrafegoRede',horaInicio,horaFim)


    def inserirTopUsuariosOnLine(self,tupla):
        problem = False
        #return
        for t in tupla:
            print '%s ' %len(t)
            print t
            parametros = t[1::]
            print 'len(parametros) %s'%len(parametros)
            nomeUsuario =  parametros[0]
            tempoOnline = parametros[1]
            url1 = parametros[2]
            url2 = parametros[3]
            url3 = parametros[4]
            qtdAcesso1 = parametros[5]
            qtdAcesso2 = parametros[6]
            qtdAcesso3 = parametros[7]
            horaInsercao = parametros[8]
            Cliente_idCliente = parametros[9]
            
            sql = """ INSERT INTO analise_rede.TopUsuariosOnLine ( nomeUsuario,  tempoOnline, url1, url2, url3, qtdAcesso1, qtdAcesso2, qtdAcesso3, horaInsercao, Cliente_idCliente ) VALUES ( "%s", %s,"%s", "%s","%s", %s,%s, %s, '%s',%s)"""%(nomeUsuario, tempoOnline, url1, url2, url3, qtdAcesso1, qtdAcesso2, qtdAcesso3,horaInsercao, Cliente_idCliente)
            print sql
            problem = self.realizarMigracao(sql, 'analise_rede.TopUsuariosOnLine')

        if len(tupla) > 0:
            horaInicio = tupla[0][9]
            horaFim = tupla[len(tupla)-1][9]
            print horaInicio,
            print horaFim

            self.realizarDelecao(problem, 'analise_rede.TopUsuariosOnLine',horaInicio,horaFim)    
            
        return

    
    
if __name__ == '__main__':

        mg = MigraBanco('nuvem','labsecur1t1','10.10.10.34','analise_rede')

        mg.migrarBanco()

