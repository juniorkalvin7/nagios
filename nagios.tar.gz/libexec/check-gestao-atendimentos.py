#!/usr/bin/env python 
# -*- coding: utf-8 -*-

import MySQLdb
import calendar
import datetime
import sys

saida = 0

args = sys.argv[1::]
if len(sys.argv) < 2:
  print 'CRITICAL - Por favor insira o(s) parâmetro(s)'
  sys.exit(2)

#print args
nome_cliente = args[0]

try:
  con = MySQLdb.connect(host='23.253.174.11', user='centreon', passwd='W2bVC6oFZP',db='otrs')
except:
  print 'CRITICAL - Não foi possível conectar com o banco. Favor verifique o usuario, senha e o nome do banco'
  sys.exit(2)

data = datetime.datetime.now()
ano = data.year
mes = data.month
num_dias_mes = calendar.monthrange(ano, mes)[1]

data_inicio = "%s-%s-01 00:00:00"%(ano, mes)
data_fim = "%s-%s-%s 23:59:59"%(ano, mes,num_dias_mes)

#print data_inicio
#print data_fim


c = con.cursor()
c.execute("""select tn, name, title
             from ticket join 
                   ticket_type on ticket.type_id = ticket_type.id 
             where ticket.create_time >= '%s' and 
                   ticket.create_time <= '%s' and 
                   ticket.customer_id = '%s' limit 1000;""" %(data_inicio,data_fim,nome_cliente));
arr = c.fetchall()


c.execute(""" select ticket.tn,ticket_type.name,ticket.title 
     from ticket JOIN  
       ticket_state_type JOIN 
       ticket_state join          
       users join 
       queue join 
       ticket_type join 
       service  
     ON  ticket.ticket_state_id = ticket_state.id and          
       ticket_state.type_id = ticket_state_type.id and     
       users.id = ticket.user_id and queue.id = ticket.queue_id and  ticket.type_id = ticket_type.id and 
       ticket.service_id = service.id 
     where ticket_state_type.id != 7 and 
       ticket.customer_id = '%s' and 
       ticket.create_time >= '%s'  
       and ticket.create_time <= '%s'; """ %(nome_cliente,data_inicio,data_fim))

arr2 = c.fetchall()

#print len(arr)
#print len(arr2)

string_tabela = ''
msg = "Total de chamados: %s. Chamados lidos: %s"%(len(arr),len(arr2))

deferenca = set(arr).difference(arr2)

string_tabela = '''<html><head><meta charset="UTF-8"/></head><body><table style="text-align:center;" border=1> <tr>  <th>N# Ticket </th>   <th>Tipo</th>   <th>Titulo</th> </tr>			
'''

if len(deferenca) > 0:
  saida = 1 
  msg = "CRITICAL - " + msg
  #string_tabela = '<table style="text-align:center;">'
  
  for dif in deferenca:
    string_tabela += '<tr style="text-align:center;" border="1">'
    string_tabela += '<td style="text-align:center;">%s</td>' %(dif[0])
    string_tabela += '<td style="text-align:center;">%s</td>' %(dif[1])
    string_tabela += '<td style="text-align:center;">%s</td>' %(dif[2])
    string_tabela += '</tr>'
#    string_tabela += '''<tr style="text-align:center;" > 
#			    <td style="text-align:center;">%s</td> 
#			    <td style="text-align:center;">%s</td> 
#			    <td style="text-align:center;">%s</td> 
#			</tr>'''%(dif[0],dif[1],dif[2])
#  string_tabela += '</table>'


else:
  msg = "OK - " + msg

  #string_tabela = '<table style="text-align:center;" border="1">'
  
  for ar in arr:
    string_tabela += '<tr style="text-align:center;" >'
    string_tabela += '<td style="text-align:center;">%s</td>' %(ar[0])
    string_tabela += '<td style="text-align:center;">%s</td>' %(ar[1])
    string_tabela += '<td style="text-align:center;">%s</td>' %(ar[2])
    string_tabela += '</tr>'

string_tabela += '</body></table></html>'

print msg + "|total_chamados=%s total_lidos=%s"%(len(arr),len(arr2))
print string_tabela.replace('\n','').replace('�','ç')

sys.exit(saida)
