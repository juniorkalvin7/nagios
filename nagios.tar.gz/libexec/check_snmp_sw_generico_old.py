#!/usr/bin/env python
# -*- coding: utf-8 -*-

import commands, sys

if len(sys.argv) < 7:
  print 'CRITICAL - Favor digitar os parametros'
  print "Ex: %s community ip mib mensagem valor_warning valor_critical"%sys.argv[0]
  print 'Ex de mensagem: "Uso do cpu", "Uso de memória"'
  sys.exit(2)
  
alarm = 0 
mib = sys.argv[3]
ip = sys.argv[2]
community = sys.argv[1]
op = sys.argv[4]
val_warning = sys.argv[5]
val_critical = sys.argv[6]


con = commands.getoutput('''/usr/bin/snmpwalk -v2c -c %s %s %s'''%(community, ip, mib))

if "timeout" in str(con).lower():
  print "WARNING - Nao foi possivel acesso via snmp"
  sys.exit(1)

else:

    valor_de_uso_atual = int(str(con).split()[-1])
  
    if valor_de_uso_atual >= val_warning and valor_de_uso_atual < val_critical :
      msg = "WARNING - "
      alarm = 1
  
    elif valor_de_uso_atual >= val_critical:
      msg = "CRITICAL - "
      alarm = 2

    else:
      msg = "OK - "

    msg += "%s e de %s%% | valor_de_uso_atual=%s "%(op,valor_de_uso_atual,valor_de_uso_atual) 
  
    
print msg      
sys.exit(alarm)

