#!/usr/bin/env python 
# -*- coding: utf-8 -*-

import MySQLdb
import calendar
import datetime
import sys


def getTotalElementosGrupo(cliente):
  try:
  #con2 = MySQLdb.connect(host='23.253.160.254', user='relatorio', passwd='W2bVC6oFZP',db='')
   con2 = MySQLdb.connect(host='127.0.0.1', user='relatorio', passwd='',db='')
  except:
    print 'CRITICAL - N?o foi poss?vel conectar com o banco do monitoramento. Favor verifique o usuario, senha e o nome do banco'
    sys.exit(2)
  
  arr_dentro = []
  con2 = con2.cursor()
  con2.execute("""select count(host_host_id)
  from centreon.hostgroup_relation  join centreon.host  
       on host_id = host_host_id
       where hostgroup_hg_id in (
             select hg_id from centreon.hostgroup
                    where hg_name = '%s' ) and host_activate = '1';"""%(cliente));
  arr_dentro = con2.fetchall()
  return int(str(arr_dentro[0]).replace("(","").replace("L,)",""))



def geraTabelaResumoQuantidades(cliente_consulta,completo):
	
  cliente_arr = cliente_consulta.split('-');
  somatorio = 0; 
      
  table = "";
  cabecalho_tabela = '<table style="width:70%;margin-left:15%; margin-top:5%; border-collapse: separate;border-spacing: 0px 3px;"> <tbody style="width:70%;">';
  tamanho_fonte_titulo ='110%';
  tam_font = "10pt";
  
  titulo = cliente_consulta;
  if(cliente_consulta == "SEMIT" and completo == "completo"):
    titulo = titulo.replace("SEMIT","PMSL");
    titulo = "SEMIT"
  elif(cliente_consulta == "SEMIT" and completo == ""):
    titulo = cliente_consulta;
    titulo = "PMSL"
  else: titulo = titulo.replace("SEMIT","PMSL") ; 
  
  cabecalho = '''
      <tr>
          <th colspan=4 style="border-right:0px solid #adadad; border-left:0px solid #adadad; border-bottom:0px solid #adadad; border-top:1px solid #adadad; font-size:'.tamanho_fonte_titulo.';margin-left:0%;text-align:center;padding: 1px; font-family: arial;" >''' + titulo + '''</th>
      </tr>
      <tr>
          <th style="border-right:0px solid #adadad; border-left:0px solid #adadad; border-bottom:3px solid darkblue; border-top:1px solid #adadad; font-size:'.tamanho_fonte_titulo.';margin-left:0%;text-align:center;padding: 1px; font-family: arial;" >Tipo</th>
          <th style="border-right:0px solid #adadad; border-left:1px solid #adadad; border-bottom:3px solid darkblue; border-top:1px solid #adadad; font-size:'.tamanho_fonte_titulo.';margin-left:0%;text-align:center;padding: 1px; font-family: arial;" > Qtd dentro do escopo</th>
          <th style="border-right:0px solid #adadad; border-left:1px solid #adadad; border-bottom:3px solid darkblue; border-top:1px solid #adadad; font-size:'.tamanho_fonte_titulo.';margin-left:0%;text-align:center;padding: 1px; font-family: arial;" > Qtd Fora do escopo</th>
          <th style="border-right:0px solid #adadad; border-left:1px solid #adadad; border-bottom:3px solid darkblue; border-top:1px solid #adadad; font-size:'.tamanho_fonte_titulo.';margin-left:0%;text-align:center;padding: 1px; font-family: arial;" > Total</th>
      </tr>''';

  string_tabela = "";
  string_tabela += '<tr>';
  valor_fora_escopo = 0;
  somatorio_fora_escopo = 0;
  
  # TIPO: Servidor
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Servidor </p> </td>';
  valor = getTotalElementosGrupo(cliente_consulta+"-CONTRATADO-SERVIDORES");
  valor_fora_escopo = 0;
  if (cliente_consulta == "SEMIT" and completo == "completo"):
    valor += getTotalElementosGrupo("CPL-CONTRATADO-SERVIDORES");
    valor += getTotalElementosGrupo("SEMED-CONTRATADO-SERVIDORES");
    valor += getTotalElementosGrupo("SEMAD-CONTRATADO-SERVIDORES");
    valor_fora_escopo = 115;
  
  somatorio_fora_escopo += valor_fora_escopo;
  somatorio += valor;
  
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+ str(('-',valor)[valor > 0]) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' + str(('-',valor + valor_fora_escopo)[(valor + valor_fora_escopo) > 0]) + '</p> </td>';
                
  string_tabela += '</tr>';
  #FIM Tipo: Servidor
  
  
  # TIPO: Roteador
  string_tabela += '<tr>';
  
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Roteador </p> </td>';
  valor = getTotalElementosGrupo(cliente_consulta + "-CONTRATADO-ROTEADORES");
  valor_fora_escopo = 0;
  if (cliente_consulta == "SEMIT" and completo == "completo"):
    valor += getTotalElementosGrupo("CPL-CONTRATADO-ROTEADORES");
    valor += getTotalElementosGrupo("SEMED-CONTRATADO-ROTEADORES");
    valor += getTotalElementosGrupo("SEMAD-CONTRATADO-ROTEADORES");
    
    valor_fora_escopo = 2;
  
  somatorio += valor;
  somatorio_fora_escopo += valor_fora_escopo;        
  
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' +  str(('-',valor)[valor > 0]) + '</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) +  '</p> </td>';        
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' + str(('-',valor + valor_fora_escopo)[(valor + valor_fora_escopo) > 0]) + '</p> </td>';
  
       
  string_tabela += '</tr>'; 
 #FIM Tipo: Roteador
  
  
  # TIPO: Swhitch e NoBreak
  string_tabela += '<tr>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Switch e NoBreak </p> </td>';
  valor = 0;
  valor = getTotalElementosGrupo(cliente_consulta + "-CONTRATADO-SWITCH-NOBREACK" );
  valor_fora_escopo = 0;
  if (cliente_consulta == "SEMIT" and completo == "completo"):
    valor += getTotalElementosGrupo("CPL-CONTRATADO-SWITCH-NOBREACK" );
    valor += getTotalElementosGrupo("SEMED-CONTRATADO-SWITCH-NOBREACK" );
    valor += getTotalElementosGrupo("SEMAD-CONTRATADO-SWITCH-NOBREACK" );
    valor_fora_escopo = 8;
  
  
  somatorio += valor;
  somatorio_fora_escopo += valor_fora_escopo;
  
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+  str(('-',valor)[valor > 0]) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) +  ' </p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' + str(('-',valor + valor_fora_escopo)[(valor + valor_fora_escopo) > 0]) + '</p> </td>';
  
  string_tabela += '</tr>';
 #FIM Tipo: Swhitch e NoBreak
        
        
  # TIPO: Radio
  string_tabela += '<tr>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Radio </p> </td>';
  valor = getTotalElementosGrupo(cliente_consulta + "-CONTRATADO-RADIOS" );
  valor_fora_escopo = 0;
  if (cliente_consulta == "SEMIT" and completo == "completo"):
    valor += getTotalElementosGrupo("CPL-CONTRATADO-RADIOS" );
    valor += getTotalElementosGrupo("SEMED-CONTRATADO-RADIOS" );
    valor += getTotalElementosGrupo("SEMAD-CONTRATADO-RADIOS" );

  
  valor_fora_escopo = 0;
  
  somatorio += valor;
  somatorio_fora_escopo += valor_fora_escopo;
  
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+  str(('-',valor)[valor > 0]) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> - </p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">' + str(('-',valor + valor_fora_escopo)[(valor + valor_fora_escopo) > 0]) + '</p> </td>';
  
  string_tabela += '</tr>';
  #FIM Tipo: Radio
      
      
  # TIPO: Outros
  string_tabela += '<tr>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Outros </p> </td>';
  valor = getTotalElementosGrupo(cliente_consulta + "-CONTRATADO-OUTROS" );
  valor_fora_escopo = 0;
  if (cliente_consulta == "SEMIT" and completo == "completo"):
    valor += getTotalElementosGrupo("CPL-CONTRATADO-OUTROS" );
    valor += getTotalElementosGrupo("SEMED-CONTRATADO-OUTROS" );
    valor += getTotalElementosGrupo("SEMAD-CONTRATADO-OUTROS" );
    valor_fora_escopo = 13;
  
  # Comentado para n?o somar com o outros
  # somatorio += valor;
  # Valor ta recebendo 0 pra n?o entrar na contagem
  # do dentro do escopo, s? na contagem dos fora
  valor = 0;
  
  somatorio_fora_escopo += valor_fora_escopo;

  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> '+ str(('-',valor)[valor > 0]) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> '+ str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) +' </p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> '+ str(('-', (valor + valor_fora_escopo))[(valor + valor_fora_escopo) > 0]) +' </p> </td>';
  string_tabela += '<tr>';
 #FIM Tipo: Outros
      
      
  # TIPO: Somatorio total
  string_tabela += '<tr>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:left; border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;"> Total </p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+ str(somatorio) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+ str(('-',somatorio_fora_escopo)[somatorio_fora_escopo > 0]) +'</p> </td>';
  string_tabela += '<td style="margin-left:0%;text-align:left;text-align:center;border-right:1px solid #adadad; border-left:0px solid #adadad; border-bottom:1px solid #adadad; border-top:0px solid #adadad;"><p style="font-size:'+ str(tam_font) +'; font-family: arial;">'+ str(('-',(somatorio + somatorio_fora_escopo))[(somatorio + somatorio_fora_escopo) > 0]) +'</p> </td>';
  # FIM Tipo: Somatorio total
      
      
  string_tabela += '</tr>';
  
  table = string_tabela;
  table = cabecalho_tabela + cabecalho + table + '</table>'
  table = table.replace('\n','').replace('<br>','').replace('</br>','')
  
  return table

saida = 0

args = sys.argv[1::]
if len(sys.argv) < 2:
  print 'CRITICAL - Por favor insira o(s) par?metro(s)'
  sys.exit(2)

#print args
#nome_cliente = args[0]
#cliente = "SEMIT-NAO-CONTRATADO";
#arr_clientes = ["SEMIT", "SEMIT", "CPL", "SEMED", "SEMAD"]

#arr_clientes = ["SEMIT"]
arr_clientes = [sys.argv[1]]
tabela = ""
completo = "completo"
if sys.argv[1] == "PMSL":
#  print 'aqui'
  arr_clientes = []
  arr_clientes = ["SEMIT"]
  completo = ""
for cliente in arr_clientes:
  if cliente == "SEMIT" and completo == "completo" :
    tabela += geraTabelaResumoQuantidades(cliente,"completo") + "</br></br>"
    completo = ""
  else:
    tabela += geraTabelaResumoQuantidades(cliente,"") + "</br></br>"

print "OK - Tabelas de resumo."
print tabela

sys.exit(0)
