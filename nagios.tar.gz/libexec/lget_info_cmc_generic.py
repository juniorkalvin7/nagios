#!/usr/bin/env python
# -*- coding: utf-8 -*-


from socket import *
import sys,commands,re
"""
0 ok
1 warning
2 critical
3 unknown
"""

def getvalue(community,ip,mib,tipo,msg,alert,version):
  #if tipo inteiro 0 ok 1 critical
  
  outputs=(commands.getoutput("/usr/bin/snmpwalk -v %s -c %s %s %s" %(version,community,str(ip),mib))).split()[-1].replace(' ','')
  #print outputs
  if tipo=='int':
    msg1=msg.split(':')[0]
    msg2=msg.split(':')[1]
    if int(outputs)== 1:
      print 'CRITICAL - %s |ok=0' % msg2
      sys.exit(2)
    elif int(outputs)==0:
      print 'OK - %s |ok=1' % msg1
      sys.exit(0)
    else:
      print 'CRITICAL - VALOR INCORRETO',outputs
      sys.exit(2)
  if tipo=='aint':
    msg1=msg.split(':')[0]
    msg2=msg.split(':')[1]
    if int(outputs)== 0:
      print 'CRITICAL - %s |ok=0' % msg2
      sys.exit(2)
    elif int(outputs)==1:
      print 'OK - %s |ok=1' % msg1
      sys.exit(0)
    else:
      print 'CRITICAL - VALOR INCORRETO',outputs
      sys.exit(2)
      
  elif tipo=='valcrit':
    msg1=msg.split(':')[0]
    msg2=msg.split(':')[1]
    if alert.count(':') == 1:
      ale=alert.split(':')[0]
      data1=alert.split(':')[1]
      if int(outputs) < int(ale):
        print 'OK - %s %s |ok=1 %s=%s' % (msg1,outputs,data1,outputs)
        sys.exit(0)
      elif int(outputs) > int(ale):
        print 'CRITICAL - %s %s |ok=1 %s=%s' % (msg2,outputs,data1,outputs)
        sys.exit(2)
      else:
        print 'CRITICAL - VALOR INCORRETO',outputs
        sys.exit(2)
    elif alert.count(':') == 2:
      warn=alert.split(':')[0]
      crit=alert.split(':')[1]
      data1=alert.split(':')[2]
      if int(outputs) < int(warn):
        print 'OK - %s %s |ok=1 %s=%s' % (msg1,outputs,data1,outputs)
        sys.exit(0)
      elif int(outputs) > int(warn) and int(outputs) < int(crit):
        print 'WARNING - %s %s |ok=1 %s=%s' % (msg2,outputs,data1,outputs)
        sys.exit(1)      
      elif int(outputs) > int(crit):
        print 'CRITICAL - %s %s |ok=0 %s=%s' % (msg2,outputs,data1,outputs)
        sys.exit(2)
      else:
        print 'CRITICAL - VALOR INCORRETO',outputs
        sys.exit(2)
    else:
      print 'CRITICAL - VALOR INCORRETO l:67'
      sys.exit(2)



if __name__ == "__main__":
  args = sys.argv[1:]
  if len(args)<2:
    print "Centreon Plugin\nGetSnmp Info 2.0 por GemayelLira"
    print """Argumentos:
Tipo de uso 3:
python ./"""+sys.argv[0]+""" IP community MIB valcrit "msg1(ok):msg2(alerta)" "valwarn:valcrit:unidademedida" "versao"
Ex.
python lget_info_cmc_generic.py 172.29.254.9 u3fr0I9b5 .1.3.6.1.4.1.161.19.3.1.7.1.0 valcrit "Quantidade SM conectados:Quantidade SM conectados" "4:8:smcounter" "2c"
"""
    sys.exit(1)
  else:
    ip=args[0]
    community=args[1]
    mib=args[2]
    tipo=args[3]
    msg=args[4]
    try:
      alert=args[5]
      if alert =='none' or alert == 'None' or alert == 'Null' or alert =='null':alert=''
    except:alert=''
    try:
      version=args[6]
      if version=='none' or version== 'None' or version=='Null' or version == 'null':version='1'
    except:version='1'
    
  getvalue(community,ip,mib,tipo,msg,alert,version)
  
