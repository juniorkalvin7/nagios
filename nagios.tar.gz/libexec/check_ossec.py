#!/usr/bin/env python
# -*- coding: utf-8 -*-

import commands, sys

saida = 0

if len(sys.argv) < 5:
  print "Por favor informe os parametros necessários no seguinte formato:"
  print "%s community ip mib op"%(sys.argv[0])
  print "op: top_usuarios"
  sys.exit(1)


args =sys.argv[1::]

community = args[0]
ip = args[1]
mib = args[2]
op = args[3]

con = str(commands.getoutput("/usr/bin/snmpwalk -v1 -c %s %s %s" %(community, ip, mib)))

corpo = '<table border=2>'
msg = ""
if  op == 'top_usuarios':
  corpo += '<th colspan=2 align=center> Top Usuarios</th>'
  corpo += '<tr align=center><th>Nome do Usuario</th><th>Quantidade de acessos</th></tr>' 
  con = con.split("Top entries for 'Username':")[1].split("Top entries for 'Level':")[0]
  con = con.replace('------------------------------------------------','')

  lista = con.split('\n')
  msg = "OK - Top usuarios"
  perf_data = ""
  for l in lista:
    if l.split('|')!= [''] and l.split('|') != [' ']:
      usuario = l.split('|')[0].replace(' ','')
      num_acessos = l.split('|')[1].replace(' ','')
      perf_data += " %s=%s"%(usuario,num_acessos)
      if usuario.lower == 'root':
        corpo += '<tr style="color:red;" align=center><td border=2>%s</td> <td border=2>%s</td></tr>'%(usuario,num_acessos)
        saida = 2
        msg = "CRITICAL - Top usuarios: usuario root logado"
      else:
        corpo += '<tr align=center><td border=2>%s</td> <td border=2>%s</td></tr>'%(usuario,num_acessos)

if  op == 'top_entrie_rules':
  corpo += '<th colspan=2 align=center> Top Entrie Rule</th>'
  corpo += '<tr align=center><th>ID</th><th>Descricao</th><th><th></tr>'
  con = con.split("Top entries for 'Rule':")[1].split("Top entries for 'Filenames':")[0]
  con = con.replace('------------------------------------------------','')

  lista = con.split('\n')
  msg = "OK - Top Entrie Rules. Nenhuma ameaça detectada."
  perf_data = ""
  
  mib = '.1.3.6.1.4.1.2022.12.3.1.2.6.116.97.98.101.108.97'
  con = str(commands.getoutput("/usr/bin/snmpwalk -v1 -c %s %s %s" %(community, ip, mib)))
  con = str(con).replace("SNMPv2-SMI::enterprises.2022.12.3.1.2.6.116.97.98.101.108.97 = STRING: ",'').replace('"','')
  alarmes = str(con).split('\n')
  alarmes = [int(i) for i in alarmes]
    

  for l in lista:
    if l.split('|')!= [''] and l.split('|') != [' '] and l.split('|') != [' "']:
       
      id = l.split('|')[0].split('-')[0].replace(' ','')
      id = int(id)
      descricao = l.split('|')[0].split('-')[1]
      num = l.split('|')[1].replace(' ','')
      perf_data += " id_%s=%s"%(id,num)
      if id in alarmes:
        corpo += '<tr align=center style="color:red;"><td style="color:red;" border=2>%s</td> <td style="color:red;" border=2>%s</td> <td style="color:red;" border=2>%s</td> </tr>'%(id,descricao, num)
        saida = 2
        msg = "CRITICAL - Top entries: possível ameaça detectada! id: %s"%(id)
#      else:
 #       corpo += '<tr align=center><td border=2>%s</td> <td border=2>%s</td> <td border=2>%s</td> </tr>'%(id,descricao, num)

     
#print msg + '|' + perf_data
print msg
corpo +=  '</table>'
print corpo
sys.exit(saida)
