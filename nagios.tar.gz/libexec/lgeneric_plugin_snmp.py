#!/usr/bin/env python
# -*- coding: utf-8 -*-


from socket import *
import sys,commands,re,zlib,base64

"""
rev:29abr16
adicionado suporte ao tipo INTEGER,Counter32
rev:22set14
forcando varias verificacoes para servidores que nao respondem na primeira tentativa e correcoes de bug
rev:6dec13
adicionado novo padrao para mensagens ALARME tipo == CRITICAL
rev:26nov13
leitura de quebra de linha ao ver <br> ele adiciona quebra de linha
rev:22nov13
adicionado novo padrao para mensagens Alarme tipo == CRITICAL
rev:2aug13
adicionado verificacao de string se contiver "can't open" alerta
rev:27jun12
adicionado verificacao da funcao self.lersnmp() alertar


"""


class genericplugin(object):
  def __init__(self, ip,community,mib,mibCompleto):
    self.ip=ip
    self.community=community
    self.mib=mib
    self.signal=0
    self.outputs=''
    self.contador=0
    self.mibCompleto=mibCompleto
  def lersnmp(self):
    corpo=''
    if self.mibCompleto==False:
      self.comando="/usr/bin/snmpwalk -v 1 -c %s %s %s.101.1" %(self.community,str(self.ip),self.mib)
    else:
      self.comando="/usr/bin/snmpwalk -v 1 -c %s %s %s" %(self.community,str(self.ip),self.mib)      
    try:
      self.outputs=(commands.getoutput(self.comando))
      #print "Comando,",self.comando
      corpo=self.outputs.split("\"")[1]
    except Exception,e:
      #print e
      self.comando="/usr/bin/snmpwalk -v 1 -c %s %s %s" %(self.community,str(self.ip),self.mib)
      self.outputs=(commands.getoutput(self.comando))
      data = self.outputs.replace('\n','quebra')
      #print data
      maior=0
      if "STRING" in data:
        for x in re.findall('= STRING:(.+?)%s'%mib[-8:],data):
          #print x
          if len(x) > maior:
            maior = len(x)
            corpo=x     
        corpo = corpo.split('quebra')
        corpo = corpo[:-1]
        corpo = "".join(corpo)
        corpo = corpo.replace('"','')
        
      elif "Counter32" in data:
        corpo = "Tipo,Counter32 %s"%data.split()[3]
      elif "INTEGER" in data:
        corpo = "Tipo,INTEGER %s"%data.split()[3]
        
      else:
        self.outputs="Problema no tipo de dado verifique %s"%data
        self.signal=3
        pass

      try:
        corpo=zlib.decompress(base64.decodestring(corpo).rstrip())
      except:
        pass
      self.outputs=corpo
    if self.contador==3:
      self.outputs='CRITICAL - TIMEOUT 3X'
    elif len(corpo)==0 and len(self.outputs)==0:
      self.contador+=1
      self.lersnmp()
    elif self.outputs==0 and len(corpo)>0:      
      self.outputs=corpo
    if '= STRING:' in self.outputs:
      self.outputs=self.outputs.split(' STRING: ')[1].replace('"','')
    #print self.contador,len(corpo),len(self.outputs),corpo
    #return self.outputs
                
  def run(self):
    try:
      self.lersnmp()
    except Exception,e:
      self.outputs='CRITICAL - Erro ao ler valor verifique o comando manualmente\n'+self.comando
      print e
    self.outputs=self.outputs.replace('<br>','\n')
    if self.outputs.count('CRITICAL'):self.signal=2
    elif 'ALARME:' in self.outputs and not "OK - " in self.outputs:self.signal=2
    elif 'Alarme:' in self.outputs and not "OK - " in self.outputs:self.signal=2
    elif self.outputs.count('WARNING'):self.signal=1
    elif self.outputs.count('UNKNOWN'):self.signal=3
    elif self.outputs.count("can't open"):self.signal=2
    elif self.outputs.count("No such file or directory"):self.signal=2
    elif self.outputs.count("No such file or directory"):self.signal=2
    elif self.outputs.count("/usr/local/"):self.signal=2
    #print self.outputs
    self.output()
    
  def output(self):
    """
    Tipos de saida: 
    0 ok
    2 critical
    1 warning
    3 unknown
    """
    print '%s' % (self.outputs)
    sys.exit(self.signal)
    

if __name__ == "__main__":
  args = sys.argv[1:]
  if len(args)<2:
    print "Centreon Plugin\nGetSnmp Info 3.0 por GemayelLira rev:29abr16"
    print "Argumentos:\npython ./%s IP community MIB" % sys.argv[0]
    print "Mib Exata:\npython ./%s IP community c MIB" % sys.argv[0]
    #print "Ex.\npython ./%s 201.65.222.194 u3fr0I9b5 .1.3.6.1.4.1.2022.11" % sys.argv[0] 
    sys.exit(1)
  else:
    ip=args[0]
    community=args[1]
    mib=args[2]
    if mib=='c':
      mib=args[3]
      mibCompleto=True
    else:mibCompleto=False

  genericplugin(ip,community,mib,mibCompleto).run()

