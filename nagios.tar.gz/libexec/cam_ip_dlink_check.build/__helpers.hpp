#ifndef __NUITKA_REVERSES_H__
#define __NUITKA_REVERSES_H__

#include "nuitka/eval_order.hpp"

#if NUITKA_REVERSED_ARGS == 0
#define EVAL_ORDERED_0(  )
#define EVAL_ORDERED_1( arg1 ) arg1
#define EVAL_ORDERED_2( arg1, arg2 ) arg1, arg2
#define EVAL_ORDERED_3( arg1, arg2, arg3 ) arg1, arg2, arg3
#define EVAL_ORDERED_4( arg1, arg2, arg3, arg4 ) arg1, arg2, arg3, arg4
#define EVAL_ORDERED_5( arg1, arg2, arg3, arg4, arg5 ) arg1, arg2, arg3, arg4, arg5
#else
#define EVAL_ORDERED_0(  )
#define EVAL_ORDERED_1( arg1 ) arg1
#define EVAL_ORDERED_2( arg1, arg2 ) arg2, arg1
#define EVAL_ORDERED_3( arg1, arg2, arg3 ) arg3, arg2, arg1
#define EVAL_ORDERED_4( arg1, arg2, arg3, arg4 ) arg4, arg3, arg2, arg1
#define EVAL_ORDERED_5( arg1, arg2, arg3, arg4, arg5 ) arg5, arg4, arg3, arg2, arg1
#endif

#endif
#ifndef __NUITKA_TUPLES_H__
#define __NUITKA_TUPLES_H__

#define MAKE_TUPLE1( arg1 ) _MAKE_TUPLE1( EVAL_ORDERED_1( arg1 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_TUPLE1( EVAL_ORDERED_1( PyObject *element0 ) )
{
    PyObject *result = PyTuple_New( 1 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( element0 );
    PyTuple_SET_ITEM( result, 0, INCREASE_REFCOUNT( element0 ) );

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_TUPLE2( arg1, arg2 ) _MAKE_TUPLE2( EVAL_ORDERED_2( arg1, arg2 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_TUPLE2( EVAL_ORDERED_2( PyObject *element0, PyObject *element1 ) )
{
    PyObject *result = PyTuple_New( 2 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( element0 );
    PyTuple_SET_ITEM( result, 0, INCREASE_REFCOUNT( element0 ) );
    assertObject( element1 );
    PyTuple_SET_ITEM( result, 1, INCREASE_REFCOUNT( element1 ) );

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_TUPLE3( arg1, arg2, arg3 ) _MAKE_TUPLE3( EVAL_ORDERED_3( arg1, arg2, arg3 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_TUPLE3( EVAL_ORDERED_3( PyObject *element0, PyObject *element1, PyObject *element2 ) )
{
    PyObject *result = PyTuple_New( 3 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( element0 );
    PyTuple_SET_ITEM( result, 0, INCREASE_REFCOUNT( element0 ) );
    assertObject( element1 );
    PyTuple_SET_ITEM( result, 1, INCREASE_REFCOUNT( element1 ) );
    assertObject( element2 );
    PyTuple_SET_ITEM( result, 2, INCREASE_REFCOUNT( element2 ) );

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_TUPLE4( arg1, arg2, arg3, arg4 ) _MAKE_TUPLE4( EVAL_ORDERED_4( arg1, arg2, arg3, arg4 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_TUPLE4( EVAL_ORDERED_4( PyObject *element0, PyObject *element1, PyObject *element2, PyObject *element3 ) )
{
    PyObject *result = PyTuple_New( 4 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( element0 );
    PyTuple_SET_ITEM( result, 0, INCREASE_REFCOUNT( element0 ) );
    assertObject( element1 );
    PyTuple_SET_ITEM( result, 1, INCREASE_REFCOUNT( element1 ) );
    assertObject( element2 );
    PyTuple_SET_ITEM( result, 2, INCREASE_REFCOUNT( element2 ) );
    assertObject( element3 );
    PyTuple_SET_ITEM( result, 3, INCREASE_REFCOUNT( element3 ) );

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_TUPLE5( arg1, arg2, arg3, arg4, arg5 ) _MAKE_TUPLE5( EVAL_ORDERED_5( arg1, arg2, arg3, arg4, arg5 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_TUPLE5( EVAL_ORDERED_5( PyObject *element0, PyObject *element1, PyObject *element2, PyObject *element3, PyObject *element4 ) )
{
    PyObject *result = PyTuple_New( 5 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( element0 );
    PyTuple_SET_ITEM( result, 0, INCREASE_REFCOUNT( element0 ) );
    assertObject( element1 );
    PyTuple_SET_ITEM( result, 1, INCREASE_REFCOUNT( element1 ) );
    assertObject( element2 );
    PyTuple_SET_ITEM( result, 2, INCREASE_REFCOUNT( element2 ) );
    assertObject( element3 );
    PyTuple_SET_ITEM( result, 3, INCREASE_REFCOUNT( element3 ) );
    assertObject( element4 );
    PyTuple_SET_ITEM( result, 4, INCREASE_REFCOUNT( element4 ) );

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#endif
#ifndef __NUITKA_LISTS_H__
#define __NUITKA_LISTS_H__

#define MAKE_LIST0(  ) _MAKE_LIST0( EVAL_ORDERED_0(  ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_LIST0( EVAL_ORDERED_0(  ) )
{
    PyObject *result = PyList_New( 0 );

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }



    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#endif
#ifndef __NUITKA_DICTS_H__
#define __NUITKA_DICTS_H__

#define MAKE_DICT0(  ) _MAKE_DICT0( EVAL_ORDERED_0(  ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_DICT0( EVAL_ORDERED_0(  ) )
{
    PyObject *result = PyDict_New();

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }



    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_DICT1( value1, key1 ) _MAKE_DICT1( EVAL_ORDERED_2( value1, key1 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_DICT1( EVAL_ORDERED_2( PyObject *value1, PyObject *key1 ) )
{
    PyObject *result = PyDict_New();

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( key1 );
    assertObject( value1 );

    {
        int status = PyDict_SetItem( result, key1, value1 );

        if (unlikely( status == -1 ))
        {
            throw _PythonException();
        }
    }

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#define MAKE_DICT2( value1, key1, value2, key2 ) _MAKE_DICT2( EVAL_ORDERED_4( value1, key1, value2, key2 ) )

NUITKA_MAY_BE_UNUSED static PyObject *_MAKE_DICT2( EVAL_ORDERED_4( PyObject *value1, PyObject *key1, PyObject *value2, PyObject *key2 ) )
{
    PyObject *result = PyDict_New();

    if (unlikely( result == NULL ))
    {
        throw _PythonException();
    }

    assertObject( key1 );
    assertObject( value1 );

    {
        int status = PyDict_SetItem( result, key1, value1 );

        if (unlikely( status == -1 ))
        {
            throw _PythonException();
        }
    }
    assertObject( key2 );
    assertObject( value2 );

    {
        int status = PyDict_SetItem( result, key2, value2 );

        if (unlikely( status == -1 ))
        {
            throw _PythonException();
        }
    }

    assert( Py_REFCNT( result ) == 1 );

    return result;
}

#endif
