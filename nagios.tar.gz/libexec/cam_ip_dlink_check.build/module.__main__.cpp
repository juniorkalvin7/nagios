// Generated code for Python source for module '__main__'
// created by Nuitka version 0.3.25

// This code is in part copyright 2012 Kay Hayen.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "nuitka/prelude.hpp"

#include "__modules.hpp"
#include "__constants.hpp"
#include "__helpers.hpp"

// The _module___main__ is a Python object pointer of module type.

// Note: For full compatability with CPython, every module variable access needs to go
// through it except for cases where the module cannot possibly have changed in the mean
// time.

PyObject *_module___main__;

// The module level variables.
static PyObjectGlobalVariable___main__ _mvar___main___AF_INET( &_module___main__, &_python_str_plain_AF_INET );
static PyObjectGlobalVariable___main__ _mvar___main___Portcheck( &_module___main__, &_python_str_plain_Portcheck );
static PyObjectGlobalVariable___main__ _mvar___main___SOCK_STREAM( &_module___main__, &_python_str_plain_SOCK_STREAM );
static PyObjectGlobalVariable___main__ _mvar___main_____doc__( &_module___main__, &_python_str_plain___doc__ );
static PyObjectGlobalVariable___main__ _mvar___main_____file__( &_module___main__, &_python_str_plain___file__ );
static PyObjectGlobalVariable___main__ _mvar___main_____metaclass__( &_module___main__, &_python_str_plain___metaclass__ );
static PyObjectGlobalVariable___main__ _mvar___main_____package__( &_module___main__, &_python_str_plain___package__ );
static PyObjectGlobalVariable___main__ _mvar___main___args( &_module___main__, &_python_str_plain_args );
static PyObjectGlobalVariable___main__ _mvar___main___base64( &_module___main__, &_python_str_plain_base64 );
static PyObjectGlobalVariable___main__ _mvar___main___host( &_module___main__, &_python_str_plain_host );
static PyObjectGlobalVariable___main__ _mvar___main___http_auth( &_module___main__, &_python_str_plain_http_auth );
static PyObjectGlobalVariable___main__ _mvar___main___os( &_module___main__, &_python_str_plain_os );
static PyObjectGlobalVariable___main__ _mvar___main___payload( &_module___main__, &_python_str_plain_payload );
static PyObjectGlobalVariable___main__ _mvar___main___senha( &_module___main__, &_python_str_plain_senha );
static PyObjectGlobalVariable___main__ _mvar___main___setdefaulttimeout( &_module___main__, &_python_str_plain_setdefaulttimeout );
static PyObjectGlobalVariable___main__ _mvar___main___socket( &_module___main__, &_python_str_plain_socket );
static PyObjectGlobalVariable___main__ _mvar___main___sys( &_module___main__, &_python_str_plain_sys );
static PyObjectGlobalVariable___main__ _mvar___main___usuario( &_module___main__, &_python_str_plain_usuario );

// The module function declarations.
static PyObject *impl_class_1_Portcheck_of_module___main__( PyObject *metaclass, PyObject *bases );
#define MAKE_FUNCTION_function_1___init___of_class_1_Portcheck_of_module___main__( defaults ) _MAKE_FUNCTION_function_1___init___of_class_1_Portcheck_of_module___main__( defaults )

static PyObject *_MAKE_FUNCTION_function_1___init___of_class_1_Portcheck_of_module___main__( PyObject *defaults );
#define MAKE_FUNCTION_function_2_run_of_class_1_Portcheck_of_module___main__( defaults ) _MAKE_FUNCTION_function_2_run_of_class_1_Portcheck_of_module___main__( defaults )

static PyObject *_MAKE_FUNCTION_function_2_run_of_class_1_Portcheck_of_module___main__( PyObject *defaults );


// The module function definitions.
static PyObject *impl_class_1_Portcheck_of_module___main__( PyObject *metaclass, PyObject *bases )
{
    // No context is used.

    // Local variable declarations.
    // Locals dictionary setup.
    PyObjectTemporary locals_dict( PyDict_New() );

    PyObjectLocalVariable _python_var___module__( _python_str_plain___module__ );
    PyObjectLocalVariable _python_var___doc__( _python_str_plain___doc__ );
    PyObjectLocalVariable _python_var___init__( _python_str_plain___init__ );
    PyObjectLocalVariable _python_var_run( _python_str_plain_run );
    PyObjectLocalVariable _python_var___class__( _python_str_plain___class__ );

    // Actual function code.
    _python_var___module__.assign0( _python_str_plain___main__ );
    _python_var___doc__.assign0( Py_None );
    static PyFrameObject *frame_class_1_Portcheck_of_module___main__ = NULL;

    if ( isFrameUnusable( frame_class_1_Portcheck_of_module___main__ ) )
    {
        if ( frame_class_1_Portcheck_of_module___main__ )
        {
#if _DEBUG_REFRAME
            puts( "reframe for class_1_Portcheck_of_module___main__" );
#endif
            Py_DECREF( frame_class_1_Portcheck_of_module___main__ );
        }

        frame_class_1_Portcheck_of_module___main__ = MAKE_FRAME( _codeobj_26a8e54758789f9ca6d1112514525569, _module___main__ );
    }

    FrameGuard frame_guard( frame_class_1_Portcheck_of_module___main__ );
    try
    {
        assert( Py_REFCNT( frame_class_1_Portcheck_of_module___main__ ) == 2 ); // Frame stack
        frame_guard.setLineNumber( 9 );
        _python_var___init__.assign1( MAKE_FUNCTION_function_1___init___of_class_1_Portcheck_of_module___main__( NULL ) );
        frame_guard.setLineNumber( 14 );
        _python_var_run.assign1( MAKE_FUNCTION_function_2_run_of_class_1_Portcheck_of_module___main__( NULL ) );
    }
    catch ( _PythonException &_exception )
    {
        if ( !_exception.hasTraceback() )
        {
            _exception.setTraceback( MAKE_TRACEBACK( frame_guard.getFrame() ) );
        }
        else
        {
            _exception.addTraceback( frame_guard.getFrame0() );
        }

        Py_XDECREF( frame_guard.getFrame0()->f_locals );
        frame_guard.getFrame0()->f_locals = INCREASE_REFCOUNT( _python_var___class__.updateLocalsDict( _python_var_run.updateLocalsDict( _python_var___init__.updateLocalsDict( _python_var___doc__.updateLocalsDict( _python_var___module__.updateLocalsDict( locals_dict.asObject() ) ) ) ) ) );

        if ( frame_guard.getFrame0() == frame_class_1_Portcheck_of_module___main__ )
        {
           Py_DECREF( frame_class_1_Portcheck_of_module___main__ );
           frame_class_1_Portcheck_of_module___main__ = NULL;
        }

        throw;
    }
    catch( ReturnValueException &_exception )
    {
        return _exception.getValue();
    }
    _python_var___class__.assign1( MAKE_CLASS( ( _mvar___main_____metaclass__.isInitialized( false ) ? _mvar___main_____metaclass__.asObject0() : NULL ), metaclass, _python_str_plain_Portcheck, bases, _python_var___class__.updateLocalsDict( _python_var_run.updateLocalsDict( _python_var___init__.updateLocalsDict( _python_var___doc__.updateLocalsDict( _python_var___module__.updateLocalsDict( locals_dict.asObject() ) ) ) ) ) ) );
    return _python_var___class__.asObject1();

    return INCREASE_REFCOUNT( Py_None );
}
static PyObject *impl_function_1___init___of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *_python_par_self, PyObject *_python_par_host, PyObject *_python_par_port )
{
    // No context is used.

    // Local variable declarations.
    PyObjectLocalParameterVariableNoDel _python_var_self( _python_str_plain_self, _python_par_self );
    PyObjectLocalParameterVariableNoDel _python_var_host( _python_str_plain_host, _python_par_host );
    PyObjectLocalParameterVariableNoDel _python_var_port( _python_str_plain_port, _python_par_port );

    // Actual function code.
    static PyFrameObject *frame_function_1___init___of_class_1_Portcheck_of_module___main__ = NULL;

    if ( isFrameUnusable( frame_function_1___init___of_class_1_Portcheck_of_module___main__ ) )
    {
        if ( frame_function_1___init___of_class_1_Portcheck_of_module___main__ )
        {
#if _DEBUG_REFRAME
            puts( "reframe for function_1___init___of_class_1_Portcheck_of_module___main__" );
#endif
            Py_DECREF( frame_function_1___init___of_class_1_Portcheck_of_module___main__ );
        }

        frame_function_1___init___of_class_1_Portcheck_of_module___main__ = MAKE_FRAME( _codeobj_374fb71bf658d90c594f3271f1b797a8, _module___main__ );
    }

    FrameGuard frame_guard( frame_function_1___init___of_class_1_Portcheck_of_module___main__ );
    try
    {
        assert( Py_REFCNT( frame_function_1___init___of_class_1_Portcheck_of_module___main__ ) == 2 ); // Frame stack
        frame_guard.setLineNumber( 10 );
        SET_ATTRIBUTE( _python_var_host.asObject(), _python_var_self.asObject(), _python_str_plain_host );
        frame_guard.setLineNumber( 11 );
        SET_ATTRIBUTE( PyObjectTemporary( TO_INT( _python_var_port.asObject() ) ).asObject(), _python_var_self.asObject(), _python_str_plain_port );
        frame_guard.setLineNumber( 12 );
        SET_ATTRIBUTE( PyObjectTemporary( CALL_FUNCTION_WITH_POSARGS( _mvar___main___setdefaulttimeout.asObject0(), _python_tuple_int_pos_30_tuple ) ).asObject(), _python_var_self.asObject(), _python_str_plain_socket );
        frame_guard.setLineNumber( 13 );
        SET_ATTRIBUTE( PyObjectTemporary( CALL_FUNCTION_WITH_POSARGS( _mvar___main___socket.asObject0(), PyObjectTemporary( MAKE_TUPLE2( _mvar___main___AF_INET.asObject0(), _mvar___main___SOCK_STREAM.asObject0() ) ).asObject() ) ).asObject(), _python_var_self.asObject(), _python_str_plain_sd );
    }
    catch ( _PythonException &_exception )
    {
        if ( !_exception.hasTraceback() )
        {
            _exception.setTraceback( MAKE_TRACEBACK( frame_guard.getFrame() ) );
        }
        else
        {
            _exception.addTraceback( frame_guard.getFrame0() );
        }

        Py_XDECREF( frame_guard.getFrame0()->f_locals );
        frame_guard.getFrame0()->f_locals = _python_var_port.updateLocalsDict( _python_var_host.updateLocalsDict( _python_var_self.updateLocalsDict( PyDict_New() ) ) );

        if ( frame_guard.getFrame0() == frame_function_1___init___of_class_1_Portcheck_of_module___main__ )
        {
           Py_DECREF( frame_function_1___init___of_class_1_Portcheck_of_module___main__ );
           frame_function_1___init___of_class_1_Portcheck_of_module___main__ = NULL;
        }

        _exception.toPython();
        return NULL;
    }
    catch( ReturnValueException &_exception )
    {
        return _exception.getValue();
    }

    return INCREASE_REFCOUNT( Py_None );
}
static PyObject *_fparse_function_1___init___of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *args, PyObject *kw )
{
    Py_ssize_t args_size = PyTuple_GET_SIZE( args );
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_size = kw ? PyDict_Size( kw ) : 0;
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_found = 0;
    Py_ssize_t args_given = args_size;
    PyObject *_python_par_self = NULL;
    PyObject *_python_par_host = NULL;
    PyObject *_python_par_port = NULL;
    int args_usable_count;
    // Copy given dictionary values to the the respective variables:
    if ( kw_size > 0 )
    {
        Py_ssize_t ppos = 0;
        PyObject *key, *value;

        while( PyDict_Next( kw, &ppos, &key, &value ) )
        {
#if PYTHON_VERSION < 300
            if (unlikely( !PyString_Check( key ) && !PyUnicode_Check( key ) ))
#else
            if (unlikely( !PyUnicode_Check( key ) ))
#endif
            {
                PyErr_Format( PyExc_TypeError, "__init__() keywords must be strings" );
                goto error_exit;
            }

            NUITKA_MAY_BE_UNUSED bool found = false;

            Py_INCREF( key );
            Py_INCREF( value );

            // Quick path, could be our value.
            if ( found == false && _python_str_plain_self == key )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }
            if ( found == false && _python_str_plain_host == key )
            {
                if (unlikely( _python_par_host ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
                    goto error_exit;
                }

                _python_par_host = value;

                found = true;
            }
            if ( found == false && _python_str_plain_port == key )
            {
                if (unlikely( _python_par_port ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
                    goto error_exit;
                }

                _python_par_port = value;

                found = true;
            }

            // Slow path, compare against all parameter names.
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_self, key ) )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_host, key ) )
            {
                if (unlikely( _python_par_host ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
                    goto error_exit;
                }

                _python_par_host = value;

                found = true;
            }
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_port, key ) )
            {
                if (unlikely( _python_par_port ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
                    goto error_exit;
                }

                _python_par_port = value;

                found = true;
            }


            Py_DECREF( key );

            if ( found == false )
            {
               Py_DECREF( value );

               PyErr_Format(
                   PyExc_TypeError,
                   "__init__() got an unexpected keyword argument '%s'",
#if PYTHON_VERSION < 300
                   PyString_Check( key ) ?
#else
                   PyUnicode_Check( key ) ?
#endif
                       Nuitka_String_AsString( key ) : "<non-string>"
               );

               goto error_exit;
            }
        }
    }

    // Check if too many arguments were given in case of non star args
    if (unlikely( args_given > 3 ))
    {
        if ( 3 == 1 )
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 positional argument (%" PY_FORMAT_SIZE_T "d given)", args_given );
#endif
        }
        else
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d positional arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given );
#endif
        }

        goto error_exit;
    }

    // Check if too little arguments were given.
    if (unlikely( args_given + kw_size < 3 ))
    {
        if ( 3 == 1 )
        {
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
        }
        else
        {
#if PYTHON_VERSION < 270
            if ( kw_size > 0 )
            {
                PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d non-keyword arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
            }
            else
#endif
            {
                if ( 3 == 3 )
                {
                    PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
                }
                else
                {
                    PyErr_Format( PyExc_TypeError, "__init__() takes at least %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
                }
            }
        }

        goto error_exit;
    }

    // Copy normal parameter values given as part of the args list to the respective variables:
    args_usable_count = args_given < 3 ? args_given : 3;

    if (likely( 0 < args_usable_count ))
    {
         if (unlikely( _python_par_self != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'self'" );
             goto error_exit;
         }

        _python_par_self = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 0 ) );
    }
    if (likely( 1 < args_usable_count ))
    {
         if (unlikely( _python_par_host != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
             goto error_exit;
         }

        _python_par_host = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 1 ) );
    }
    if (likely( 2 < args_usable_count ))
    {
         if (unlikely( _python_par_port != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
             goto error_exit;
         }

        _python_par_port = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 2 ) );
    }


    return impl_function_1___init___of_class_1_Portcheck_of_module___main__( self, _python_par_self, _python_par_host, _python_par_port );

error_exit:;

    Py_XDECREF( _python_par_self );
    Py_XDECREF( _python_par_host );
    Py_XDECREF( _python_par_port );

    return NULL;
}
static PyObject *_mparse_function_1___init___of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *_python_par_self, PyObject *args, PyObject *kw )
{
    Py_INCREF( _python_par_self );

    Py_ssize_t args_size = PyTuple_GET_SIZE( args );
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_size = kw ? PyDict_Size( kw ) : 0;
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_found = 0;
    Py_ssize_t args_given = args_size + 1; // Count the self parameter already given as well.
    PyObject *_python_par_host = NULL;
    PyObject *_python_par_port = NULL;
    int args_usable_count;
    // Copy given dictionary values to the the respective variables:
    if ( kw_size > 0 )
    {
        Py_ssize_t ppos = 0;
        PyObject *key, *value;

        while( PyDict_Next( kw, &ppos, &key, &value ) )
        {
#if PYTHON_VERSION < 300
            if (unlikely( !PyString_Check( key ) && !PyUnicode_Check( key ) ))
#else
            if (unlikely( !PyUnicode_Check( key ) ))
#endif
            {
                PyErr_Format( PyExc_TypeError, "__init__() keywords must be strings" );
                goto error_exit;
            }

            NUITKA_MAY_BE_UNUSED bool found = false;

            Py_INCREF( key );
            Py_INCREF( value );

            // Quick path, could be our value.
            if ( found == false && _python_str_plain_self == key )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }
            if ( found == false && _python_str_plain_host == key )
            {
                if (unlikely( _python_par_host ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
                    goto error_exit;
                }

                _python_par_host = value;

                found = true;
            }
            if ( found == false && _python_str_plain_port == key )
            {
                if (unlikely( _python_par_port ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
                    goto error_exit;
                }

                _python_par_port = value;

                found = true;
            }

            // Slow path, compare against all parameter names.
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_self, key ) )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_host, key ) )
            {
                if (unlikely( _python_par_host ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
                    goto error_exit;
                }

                _python_par_host = value;

                found = true;
            }
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_port, key ) )
            {
                if (unlikely( _python_par_port ))
                {
                    PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
                    goto error_exit;
                }

                _python_par_port = value;

                found = true;
            }


            Py_DECREF( key );

            if ( found == false )
            {
               Py_DECREF( value );

               PyErr_Format(
                   PyExc_TypeError,
                   "__init__() got an unexpected keyword argument '%s'",
#if PYTHON_VERSION < 300
                   PyString_Check( key ) ?
#else
                   PyUnicode_Check( key ) ?
#endif
                       Nuitka_String_AsString( key ) : "<non-string>"
               );

               goto error_exit;
            }
        }
    }

    // Check if too many arguments were given in case of non star args
    if (unlikely( args_given > 3 ))
    {
        if ( 3 == 1 )
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 positional argument (%" PY_FORMAT_SIZE_T "d given)", args_given );
#endif
        }
        else
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d positional arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given );
#endif
        }

        goto error_exit;
    }

    // Check if too little arguments were given.
    if (unlikely( args_given + kw_size < 3 ))
    {
        if ( 3 == 1 )
        {
            PyErr_Format( PyExc_TypeError, "__init__() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
        }
        else
        {
#if PYTHON_VERSION < 270
            if ( kw_size > 0 )
            {
                PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d non-keyword arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
            }
            else
#endif
            {
                if ( 3 == 3 )
                {
                    PyErr_Format( PyExc_TypeError, "__init__() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
                }
                else
                {
                    PyErr_Format( PyExc_TypeError, "__init__() takes at least %d arguments (%" PY_FORMAT_SIZE_T "d given)", 3, args_given + kw_size );
                }
            }
        }

        goto error_exit;
    }

    // Copy normal parameter values given as part of the args list to the respective variables:
    args_usable_count = args_given < 3 ? args_given : 3;

    if (likely( 1 < args_usable_count ))
    {
         if (unlikely( _python_par_host != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'host'" );
             goto error_exit;
         }

        _python_par_host = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 0 ) );
    }
    if (likely( 2 < args_usable_count ))
    {
         if (unlikely( _python_par_port != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "__init__() got multiple values for keyword argument 'port'" );
             goto error_exit;
         }

        _python_par_port = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 1 ) );
    }


    return impl_function_1___init___of_class_1_Portcheck_of_module___main__( self, _python_par_self, _python_par_host, _python_par_port );

error_exit:;

    Py_XDECREF( _python_par_self );
    Py_XDECREF( _python_par_host );
    Py_XDECREF( _python_par_port );

    return NULL;
}

static PyObject *_MAKE_FUNCTION_function_1___init___of_class_1_Portcheck_of_module___main__( PyObject *defaults )
{
    PyObject *result = Nuitka_Function_New(
        _fparse_function_1___init___of_class_1_Portcheck_of_module___main__,
        _mparse_function_1___init___of_class_1_Portcheck_of_module___main__,
        _python_str_plain___init__,
        _codeobj_374fb71bf658d90c594f3271f1b797a8,
        defaults,
        _module___main__,
        Py_None
    );

    return result;
}
static PyObject *impl_function_2_run_of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *_python_par_self )
{
    // No context is used.

    // Local variable declarations.
    FrameExceptionKeeper _frame_exception_keeper;
    PyObjectLocalParameterVariableNoDel _python_var_self( _python_str_plain_self, _python_par_self );

    // Actual function code.
    static PyFrameObject *frame_function_2_run_of_class_1_Portcheck_of_module___main__ = NULL;

    if ( isFrameUnusable( frame_function_2_run_of_class_1_Portcheck_of_module___main__ ) )
    {
        if ( frame_function_2_run_of_class_1_Portcheck_of_module___main__ )
        {
#if _DEBUG_REFRAME
            puts( "reframe for function_2_run_of_class_1_Portcheck_of_module___main__" );
#endif
            Py_DECREF( frame_function_2_run_of_class_1_Portcheck_of_module___main__ );
        }

        frame_function_2_run_of_class_1_Portcheck_of_module___main__ = MAKE_FRAME( _codeobj_e74af067d5c48bcdb94198dd988ac273, _module___main__ );
    }

    FrameGuard frame_guard( frame_function_2_run_of_class_1_Portcheck_of_module___main__ );
    try
    {
        assert( Py_REFCNT( frame_function_2_run_of_class_1_Portcheck_of_module___main__ ) == 2 ); // Frame stack
        frame_guard.setLineNumber( 15 );
        _frame_exception_keeper.preserveExistingException();
        try
        {
            frame_guard.setLineNumber( 16 );
            DECREASE_REFCOUNT( CALL_FUNCTION_WITH_POSARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( PyObjectTemporary( LOOKUP_ATTRIBUTE( _python_var_self.asObject(), _python_str_plain_sd ) ).asObject(), _python_str_plain_connect ) ).asObject(), PyObjectTemporary( MAKE_TUPLE1( PyObjectTemporary( MAKE_TUPLE2( PyObjectTemporary( LOOKUP_ATTRIBUTE( _python_var_self.asObject(), _python_str_plain_host ) ).asObject(), PyObjectTemporary( LOOKUP_ATTRIBUTE( _python_var_self.asObject(), _python_str_plain_port ) ).asObject() ) ).asObject() ) ).asObject() ) );
            frame_guard.setLineNumber( 17 );
            DECREASE_REFCOUNT( CALL_FUNCTION_NO_ARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( PyObjectTemporary( LOOKUP_ATTRIBUTE( _python_var_self.asObject(), _python_str_plain_sd ) ).asObject(), _python_str_plain_close ) ).asObject() ) );
            return INCREASE_REFCOUNT( Py_True );
        }
        catch ( _PythonException &_exception )
        {
            if ( !_exception.hasTraceback() )
            {
                _exception.setTraceback( MAKE_TRACEBACK( frame_guard.getFrame() ) );
            }
            else
            {
                _exception.addTraceback( frame_guard.getFrame0() );
            }

#if PYTHON_VERSION > 300
            PythonExceptionStacker exception_restorer;
#endif

            _exception.toExceptionHandler();

            if (true)
            {
                frame_guard.detachFrame();
                return INCREASE_REFCOUNT( Py_False );
            }
            else
            {
                PyTracebackObject *tb = _exception.getTraceback();
                frame_guard.setLineNumber( tb->tb_lineno );
                _exception.setTraceback( tb->tb_next );
                tb->tb_next = NULL;

                throw;
            }
        }
    }
    catch ( _PythonException &_exception )
    {
        if ( !_exception.hasTraceback() )
        {
            _exception.setTraceback( MAKE_TRACEBACK( frame_guard.getFrame() ) );
        }
        else
        {
            _exception.addTraceback( frame_guard.getFrame0() );
        }

        Py_XDECREF( frame_guard.getFrame0()->f_locals );
        frame_guard.getFrame0()->f_locals = _python_var_self.updateLocalsDict( PyDict_New() );

        if ( frame_guard.getFrame0() == frame_function_2_run_of_class_1_Portcheck_of_module___main__ )
        {
           Py_DECREF( frame_function_2_run_of_class_1_Portcheck_of_module___main__ );
           frame_function_2_run_of_class_1_Portcheck_of_module___main__ = NULL;
        }

        _exception.toPython();
        return NULL;
    }
    catch( ReturnValueException &_exception )
    {
        return _exception.getValue();
    }

    return INCREASE_REFCOUNT( Py_None );
}
static PyObject *_fparse_function_2_run_of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *args, PyObject *kw )
{
    Py_ssize_t args_size = PyTuple_GET_SIZE( args );
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_size = kw ? PyDict_Size( kw ) : 0;
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_found = 0;
    Py_ssize_t args_given = args_size;
    PyObject *_python_par_self = NULL;
    int args_usable_count;
    // Copy given dictionary values to the the respective variables:
    if ( kw_size > 0 )
    {
        Py_ssize_t ppos = 0;
        PyObject *key, *value;

        while( PyDict_Next( kw, &ppos, &key, &value ) )
        {
#if PYTHON_VERSION < 300
            if (unlikely( !PyString_Check( key ) && !PyUnicode_Check( key ) ))
#else
            if (unlikely( !PyUnicode_Check( key ) ))
#endif
            {
                PyErr_Format( PyExc_TypeError, "run() keywords must be strings" );
                goto error_exit;
            }

            NUITKA_MAY_BE_UNUSED bool found = false;

            Py_INCREF( key );
            Py_INCREF( value );

            // Quick path, could be our value.
            if ( found == false && _python_str_plain_self == key )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "run() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }

            // Slow path, compare against all parameter names.
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_self, key ) )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "run() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }


            Py_DECREF( key );

            if ( found == false )
            {
               Py_DECREF( value );

               PyErr_Format(
                   PyExc_TypeError,
                   "run() got an unexpected keyword argument '%s'",
#if PYTHON_VERSION < 300
                   PyString_Check( key ) ?
#else
                   PyUnicode_Check( key ) ?
#endif
                       Nuitka_String_AsString( key ) : "<non-string>"
               );

               goto error_exit;
            }
        }
    }

    // Check if too many arguments were given in case of non star args
    if (unlikely( args_given > 1 ))
    {
        if ( 1 == 1 )
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 positional argument (%" PY_FORMAT_SIZE_T "d given)", args_given );
#endif
        }
        else
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "run() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "run() takes exactly %d positional arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given );
#endif
        }

        goto error_exit;
    }

    // Check if too little arguments were given.
    if (unlikely( args_given + kw_size < 1 ))
    {
        if ( 1 == 1 )
        {
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
        }
        else
        {
#if PYTHON_VERSION < 270
            if ( kw_size > 0 )
            {
                PyErr_Format( PyExc_TypeError, "run() takes exactly %d non-keyword arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
            }
            else
#endif
            {
                if ( 1 == 1 )
                {
                    PyErr_Format( PyExc_TypeError, "run() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
                }
                else
                {
                    PyErr_Format( PyExc_TypeError, "run() takes at least %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
                }
            }
        }

        goto error_exit;
    }

    // Copy normal parameter values given as part of the args list to the respective variables:
    args_usable_count = args_given < 1 ? args_given : 1;

    if (likely( 0 < args_usable_count ))
    {
         if (unlikely( _python_par_self != NULL ))
         {
             PyErr_Format( PyExc_TypeError, "run() got multiple values for keyword argument 'self'" );
             goto error_exit;
         }

        _python_par_self = INCREASE_REFCOUNT( PyTuple_GET_ITEM( args, 0 ) );
    }


    return impl_function_2_run_of_class_1_Portcheck_of_module___main__( self, _python_par_self );

error_exit:;

    Py_XDECREF( _python_par_self );

    return NULL;
}
static PyObject *_mparse_function_2_run_of_class_1_Portcheck_of_module___main__( Nuitka_FunctionObject *self, PyObject *_python_par_self, PyObject *args, PyObject *kw )
{
    Py_INCREF( _python_par_self );

    Py_ssize_t args_size = PyTuple_GET_SIZE( args );
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_size = kw ? PyDict_Size( kw ) : 0;
    NUITKA_MAY_BE_UNUSED Py_ssize_t kw_found = 0;
    Py_ssize_t args_given = args_size + 1; // Count the self parameter already given as well.
    // Copy given dictionary values to the the respective variables:
    if ( kw_size > 0 )
    {
        Py_ssize_t ppos = 0;
        PyObject *key, *value;

        while( PyDict_Next( kw, &ppos, &key, &value ) )
        {
#if PYTHON_VERSION < 300
            if (unlikely( !PyString_Check( key ) && !PyUnicode_Check( key ) ))
#else
            if (unlikely( !PyUnicode_Check( key ) ))
#endif
            {
                PyErr_Format( PyExc_TypeError, "run() keywords must be strings" );
                goto error_exit;
            }

            NUITKA_MAY_BE_UNUSED bool found = false;

            Py_INCREF( key );
            Py_INCREF( value );

            // Quick path, could be our value.
            if ( found == false && _python_str_plain_self == key )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "run() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }

            // Slow path, compare against all parameter names.
            if ( found == false && RICH_COMPARE_BOOL_EQ_PARAMETERS( _python_str_plain_self, key ) )
            {
                if (unlikely( _python_par_self ))
                {
                    PyErr_Format( PyExc_TypeError, "run() got multiple values for keyword argument 'self'" );
                    goto error_exit;
                }

                _python_par_self = value;

                found = true;
            }


            Py_DECREF( key );

            if ( found == false )
            {
               Py_DECREF( value );

               PyErr_Format(
                   PyExc_TypeError,
                   "run() got an unexpected keyword argument '%s'",
#if PYTHON_VERSION < 300
                   PyString_Check( key ) ?
#else
                   PyUnicode_Check( key ) ?
#endif
                       Nuitka_String_AsString( key ) : "<non-string>"
               );

               goto error_exit;
            }
        }
    }

    // Check if too many arguments were given in case of non star args
    if (unlikely( args_given > 1 ))
    {
        if ( 1 == 1 )
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 positional argument (%" PY_FORMAT_SIZE_T "d given)", args_given );
#endif
        }
        else
        {
#if PYTHON_VERSION < 300
            PyErr_Format( PyExc_TypeError, "run() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
#else
            PyErr_Format( PyExc_TypeError, "run() takes exactly %d positional arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given );
#endif
        }

        goto error_exit;
    }

    // Check if too little arguments were given.
    if (unlikely( args_given + kw_size < 1 ))
    {
        if ( 1 == 1 )
        {
            PyErr_Format( PyExc_TypeError, "run() takes exactly 1 argument (%" PY_FORMAT_SIZE_T "d given)", args_given + kw_size );
        }
        else
        {
#if PYTHON_VERSION < 270
            if ( kw_size > 0 )
            {
                PyErr_Format( PyExc_TypeError, "run() takes exactly %d non-keyword arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
            }
            else
#endif
            {
                if ( 1 == 1 )
                {
                    PyErr_Format( PyExc_TypeError, "run() takes exactly %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
                }
                else
                {
                    PyErr_Format( PyExc_TypeError, "run() takes at least %d arguments (%" PY_FORMAT_SIZE_T "d given)", 1, args_given + kw_size );
                }
            }
        }

        goto error_exit;
    }


    return impl_function_2_run_of_class_1_Portcheck_of_module___main__( self, _python_par_self );

error_exit:;

    Py_XDECREF( _python_par_self );

    return NULL;
}

static PyObject *_MAKE_FUNCTION_function_2_run_of_class_1_Portcheck_of_module___main__( PyObject *defaults )
{
    PyObject *result = Nuitka_Function_New(
        _fparse_function_2_run_of_class_1_Portcheck_of_module___main__,
        _mparse_function_2_run_of_class_1_Portcheck_of_module___main__,
        _python_str_plain_run,
        _codeobj_e74af067d5c48bcdb94198dd988ac273,
        defaults,
        _module___main__,
        Py_None
    );

    return result;
}


// Frame object of the module.
static PyFrameObject *frame___main__;

#if PYTHON_VERSION >= 300
static struct PyModuleDef _moduledef =
{
    PyModuleDef_HEAD_INIT,
    "__main__",   /* m_name */
    NULL,                /* m_doc */
    -1,                  /* m_size */
    NULL,                /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
  };
#endif

#define _MODULE_UNFREEZER 0

#if _MODULE_UNFREEZER
// For embedded modules, to be unpacked. Used by main program/package only
extern void registerMetaPathBasedUnfreezer( struct _inittab *_frozes_modules );

// Our own inittab for lookup of "frozen" modules, i.e. the ones included in this binary.
static struct _inittab _frozes_modules[] =
{

    { NULL, NULL }
};
#endif

#ifdef _NUITKA_EXE
static bool init_done = false;
#endif

// The exported interface to CPython. On import of the module, this function gets
// called. It has have that exact function name.

MOD_INIT_DECL( __main__ )
{
#ifdef _NUITKA_EXE
    // Packages can be imported recursively in deep executables.
    if ( init_done )
    {
        return MOD_RETURN_VALUE( _module___main__ );
    }
    else
    {
        init_done = true;
    }
#endif

#ifdef _NUITKA_MODULE
    // In case of a stand alone extension module, need to call initialization the init here
    // because that's how we are going to get called here.

    // Initialize the constant values used.
    _initConstants();

    // Initialize the compiled types of Nuitka.
    PyType_Ready( &Nuitka_Generator_Type );
    PyType_Ready( &Nuitka_Function_Type );
    PyType_Ready( &Nuitka_Method_Type );
    PyType_Ready( &Nuitka_Frame_Type );

    patchInspectModule();
#endif

#if _MODULE_UNFREEZER
    registerMetaPathBasedUnfreezer( _frozes_modules );
#endif

    // puts( "in init__main__" );

    // Create the module object first. There are no methods initially, all are added
    // dynamically in actual code only.  Also no __doc__ is initially set, as it could not
    // contain 0 this way, added early in actual code.  No self for modules, we have no
    // use for it.
#if PYTHON_VERSION < 300
    _module___main__ = Py_InitModule4(
        "__main__",       // Module Name
        NULL,                    // No methods initially, all are added dynamically in actual code only.
        NULL,                    // No __doc__ is initially set, as it could not contain 0 this way, added early in actual code.
        NULL,                    // No self for modules, we don't use it.
        PYTHON_API_VERSION
    );
#else
    _module___main__ = PyModule_Create( &_moduledef );
#endif

    assertObject( _module___main__ );

#ifndef _NUITKA_MODULE
// TODO: Seems to work for Python2.7 as well, and maybe even useful. To be
// investigated in separate tests.
#if PYTHON_VERSION >= 300
    {
        int r = PyObject_SetItem( PySys_GetObject( (char *)"modules" ), _python_str_plain___main__, _module___main__ );

        assert( r != -1 );
    }
#endif
#endif

    // For deep importing of a module we need to have "__builtins__", so we set it
    // ourselves in the same way than CPython does. Note: This must be done before
    // the frame object is allocated, or else it may fail.

    PyObject *module_dict = PyModule_GetDict( _module___main__ );

    if ( PyDict_GetItem( module_dict, _python_str_plain___builtins__ ) == NULL )
    {
        PyObject *value = ( PyObject *)module_builtin;

#ifndef _NUITKA_MODULE
        if ( _module___main__ != _module___main__ )
        {
            value = PyModule_GetDict( value );
        }
#endif

#ifndef __NUITKA_NO_ASSERT__
        int res =
#endif
            PyDict_SetItem( module_dict, _python_str_plain___builtins__, value );

        assert( res == 0 );
    }

#if PYTHON_VERSION >= 300
    {
#ifndef __NUITKA_NO_ASSERT__
        int res =
#endif
            PyDict_SetItem( module_dict, _python_str_plain___cached__, Py_None );

        assert( res == 0 );
    }
#endif

    frame___main__ = MAKE_FRAME( _codeobj_feb21887f355ed3558339f59c7dc83d1, _module___main__ );

    // Set module frame as the currently active one.
    FrameGuardLight frame_guard( &frame___main__ );

    // Push the new frame as the currently active one.
    pushFrameStack( frame___main__ );

    // Initialize the standard module attributes.
    _mvar___main_____doc__.assign0( Py_None );
    _mvar___main_____file__.assign0( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad );
#if 0
    _mvar___main_____path__.assign0(  );
#endif


    // Module code
    try
    {
        // To restore the initial exception, could be made dependent on actual try/except statement
        // as it is done for functions/classes already.
        FrameExceptionKeeper _frame_exception_keeper;
        frame_guard.setLineNumber( 3 );
        _mvar___main___sys.assign1( IMPORT_MODULE( _python_str_plain_sys, PyModule_GetDict( _module___main__ ), PyModule_GetDict( _module___main__ ), Py_None, _python_int_neg_1 ) );
        _mvar___main___base64.assign1( IMPORT_MODULE( _python_str_plain_base64, PyModule_GetDict( _module___main__ ), PyModule_GetDict( _module___main__ ), Py_None, _python_int_neg_1 ) );
        _mvar___main___os.assign1( IMPORT_MODULE( _python_str_plain_os, PyModule_GetDict( _module___main__ ), PyModule_GetDict( _module___main__ ), Py_None, _python_int_neg_1 ) );
        frame_guard.setLineNumber( 4 );
        IMPORT_MODULE_STAR( _module___main__, true, PyObjectTemporary( IMPORT_MODULE( _python_str_plain_socket, PyModule_GetDict( _module___main__ ), PyModule_GetDict( _module___main__ ), _python_tuple_str_chr_42_tuple, _python_int_neg_1 ) ).asObject() );
        frame_guard.setLineNumber( 6 );
        _mvar___main___args.assign1( LOOKUP_INDEX_SLICE( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___sys.asObject0(), _python_str_plain_argv ) ).asObject(), 1, PY_SSIZE_T_MAX ) );
        frame_guard.setLineNumber( 8 );
        _mvar___main___Portcheck.assign1( impl_class_1_Portcheck_of_module___main__( NULL, _python_tuple_empty ) );
        frame_guard.setLineNumber( 21 );
        if ( RICH_COMPARE_BOOL_LT( PyObjectTemporary( BUILTIN_LEN( _mvar___main___args.asObject0() ) ).asObject(), _python_int_pos_3 ) )
        {
            frame_guard.setLineNumber( 22 );
            PRINT_ITEM_TO( NULL, _python_str_digest_64dfb2302b4d9a51a8668845d5edf960 );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 23 );
            PRINT_ITEM_TO( NULL, _python_str_digest_9c967cd0b8baf94d3c898fe2e9fa5059 );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 24 );
            PRINT_ITEM_TO( NULL, _python_str_digest_b305ab42a19abc9953618edae7bb8c2c );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 25 );
            PRINT_ITEM_TO( NULL, PyObjectTemporary( BINARY_OPERATION_ADD( PyObjectTemporary( BINARY_OPERATION_ADD( _python_str_digest_3c2788059e6a1ff2edce5fa4a8975bdc, PyObjectTemporary( CALL_FUNCTION_NO_ARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___os.asObject0(), _python_str_plain_getcwd ) ).asObject() ) ).asObject() ) ).asObject(), PyObjectTemporary( BINARY_OPERATION_REMAINDER( _python_str_digest_d52606db387a7837da16e6e0fc09954d, PyObjectTemporary( LOOKUP_SUBSCRIPT_CONST( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___sys.asObject0(), _python_str_plain_argv ) ).asObject(), _python_int_0, 0 ) ).asObject() ) ).asObject() ) ).asObject() );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 26 );
            DECREASE_REFCOUNT( CALL_FUNCTION_WITH_POSARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___sys.asObject0(), _python_str_plain_exit ) ).asObject(), _python_tuple_int_pos_1_tuple ) );
        }
        else
        {
            frame_guard.setLineNumber( 28 );
            _mvar___main___host.assign1( LOOKUP_SUBSCRIPT_CONST( _mvar___main___args.asObject0(), _python_int_0, 0 ) );
            frame_guard.setLineNumber( 29 );
            _mvar___main___usuario.assign1( LOOKUP_SUBSCRIPT_CONST( _mvar___main___args.asObject0(), _python_int_pos_1, 1 ) );
            frame_guard.setLineNumber( 30 );
            if ( RICH_COMPARE_BOOL_EQ( PyObjectTemporary( LOOKUP_SUBSCRIPT_CONST( _mvar___main___args.asObject0(), _python_int_pos_2, 2 ) ).asObject(), _python_str_plain_none ) )
            {
                _mvar___main___senha.assign0( _python_str_empty );
            }
            else
            {
                frame_guard.setLineNumber( 33 );
                _mvar___main___senha.assign1( LOOKUP_SUBSCRIPT_CONST( _mvar___main___args.asObject0(), _python_int_pos_2, 2 ) );
            }
        }
        frame_guard.setLineNumber( 35 );
        _mvar___main___http_auth.assign1( CALL_FUNCTION_WITH_POSARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___base64.asObject0(), _python_str_plain_b64encode ) ).asObject(), PyObjectTemporary( MAKE_TUPLE1( PyObjectTemporary( BINARY_OPERATION_REMAINDER( _python_str_digest_530ccab821bb1f0f9080f24abeeee028, PyObjectTemporary( MAKE_TUPLE2( _mvar___main___usuario.asObject0(), _mvar___main___senha.asObject0() ) ).asObject() ) ).asObject() ) ).asObject() ) );
        frame_guard.setLineNumber( 36 );
        if ( CHECK_IF_TRUE( PyObjectTemporary( CALL_FUNCTION_NO_ARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( PyObjectTemporary( CALL_FUNCTION_WITH_POSARGS( _mvar___main___Portcheck.asObject0(), PyObjectTemporary( MAKE_TUPLE2( _mvar___main___host.asObject0(), _python_int_pos_80 ) ).asObject() ) ).asObject(), _python_str_plain_run ) ).asObject() ) ).asObject() ) )
        {
            frame_guard.setLineNumber( 37 );
            PRINT_ITEM_TO( NULL, _python_str_digest_86148bc46ac2e0e401d1955bb2dcffe2 );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 38 );
            _mvar___main___payload.assign1( BINARY_OPERATION_ADD( PyObjectTemporary( BINARY_OPERATION_ADD( PyObjectTemporary( BINARY_OPERATION_ADD( PyObjectTemporary( BINARY_OPERATION_ADD( _python_str_digest_62f4fd1940599795f77ea5c7c47bf916, _mvar___main___http_auth.asObject0() ) ).asObject(), _python_str_digest_0f78f5177614074f59079dfa843863b1 ) ).asObject(), _mvar___main___host.asObject0() ) ).asObject(), _python_str_digest_f6a23bf83e1793bc2142adda2d0bedf6 ) );
            frame_guard.setLineNumber( 51 );
            PRINT_ITEM_TO( NULL, PyObjectTemporary( BINARY_OPERATION_REMAINDER( _python_str_digest_5fef1df6f22c3c9353e02c007e3294e2, PyObjectTemporary( CALL_FUNCTION_WITH_POSARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___base64.asObject0(), _python_str_plain_b64encode ) ).asObject(), PyObjectTemporary( MAKE_TUPLE1( _mvar___main___payload.asObject0() ) ).asObject() ) ).asObject() ) ).asObject() );
            PRINT_NEW_LINE_TO( NULL );
        }
        else
        {
            frame_guard.setLineNumber( 53 );
            PRINT_ITEM_TO( NULL, _python_str_digest_d1822614df7596f404aafe7d0dc88942 );
            PRINT_NEW_LINE_TO( NULL );
            frame_guard.setLineNumber( 54 );
            DECREASE_REFCOUNT( CALL_FUNCTION_WITH_POSARGS( PyObjectTemporary( LOOKUP_ATTRIBUTE( _mvar___main___sys.asObject0(), _python_str_plain_exit ) ).asObject(), _python_tuple_int_pos_2_tuple ) );
        }
    }
    catch ( _PythonException &_exception )
    {
        if ( !_exception.hasTraceback() )
        {
            _exception.setTraceback( MAKE_TRACEBACK( frame_guard.getFrame() ) );
        }
        else
        {
            _exception.addTraceback( frame_guard.getFrame0() );
        }

        _exception.toPython();
    }

    // Pop the frame from the frame stack, we are done here.
    assert( PyThreadState_GET()->frame == frame___main__ );
    PyThreadState_GET()->frame = INCREASE_REFCOUNT_X( PyThreadState_GET()->frame->f_back );

    // puts( "out init__main__" );

    return MOD_RETURN_VALUE( _module___main__ );
}
// The main program for C++. It needs to prepare the interpreter and then calls the
// initialization code of the __main__ module.

int main( int argc, char *argv[] )
{
    Py_Initialize();
    setCommandLineParameters( argc, argv );

    // Initialize the constant values used.
    _initConstants();

    // Initialize the compiled types of Nuitka.
    PyType_Ready( &Nuitka_Generator_Type );
    PyType_Ready( &Nuitka_Function_Type );
    PyType_Ready( &Nuitka_Method_Type );
    PyType_Ready( &Nuitka_Frame_Type );

    enhancePythonTypes();

    // Set the sys.executable path to the original Python executable on Linux
    // or to python.exe on Windows.
    PySys_SetObject(
        (char *)"executable",
        _python_str_digest_7e05873b0d0f8fdd2e0058fc1a19e73a
    );

    patchInspectModule();

    // Execute the "__main__" module init function.
    MOD_INIT_NAME( __main__)();

    if ( ERROR_OCCURED() )
    {
        assertFrameObject( frame___main__ );
        assert( frame___main__->f_back == NULL );

        // Cleanup code may need a frame, so put it back.
        Py_INCREF( frame___main__ );
        PyThreadState_GET()->frame = frame___main__;

        PyErr_PrintEx( 0 );
        Py_Exit( 1 );
    }
    else
    {
        Py_Exit( 0 );
    }
}
