
#include "nuitka/prelude.hpp"

// Sentinel PyObject to be used for all our call iterator endings. It will become
// a PyCObject pointing to NULL. It's address is unique, and that's enough.
PyObject *_sentinel_value = NULL;

PyModuleObject *module_builtin = NULL;

PyCodeObject *_codeobj_feb21887f355ed3558339f59c7dc83d1;
PyCodeObject *_codeobj_26a8e54758789f9ca6d1112514525569;
PyCodeObject *_codeobj_374fb71bf658d90c594f3271f1b797a8;
PyCodeObject *_codeobj_e74af067d5c48bcdb94198dd988ac273;
PyObject *_python_dict_empty;
PyObject *_python_int_0;
PyObject *_python_int_neg_1;
PyObject *_python_int_pos_1;
PyObject *_python_int_pos_2;
PyObject *_python_int_pos_3;
PyObject *_python_int_pos_80;
PyObject *_python_str_angle_module;
PyObject *_python_str_digest_0f78f5177614074f59079dfa843863b1;
PyObject *_python_str_digest_3c2788059e6a1ff2edce5fa4a8975bdc;
PyObject *_python_str_digest_530ccab821bb1f0f9080f24abeeee028;
PyObject *_python_str_digest_5fef1df6f22c3c9353e02c007e3294e2;
PyObject *_python_str_digest_62f4fd1940599795f77ea5c7c47bf916;
PyObject *_python_str_digest_64dfb2302b4d9a51a8668845d5edf960;
PyObject *_python_str_digest_7e05873b0d0f8fdd2e0058fc1a19e73a;
PyObject *_python_str_digest_86148bc46ac2e0e401d1955bb2dcffe2;
PyObject *_python_str_digest_9c967cd0b8baf94d3c898fe2e9fa5059;
PyObject *_python_str_digest_b305ab42a19abc9953618edae7bb8c2c;
PyObject *_python_str_digest_d1822614df7596f404aafe7d0dc88942;
PyObject *_python_str_digest_d52606db387a7837da16e6e0fc09954d;
PyObject *_python_str_digest_f41f8bca78e2c33508d215ae4ef7acad;
PyObject *_python_str_digest_f6a23bf83e1793bc2142adda2d0bedf6;
PyObject *_python_str_empty;
PyObject *_python_str_plain_AF_INET;
PyObject *_python_str_plain_Portcheck;
PyObject *_python_str_plain_SOCK_STREAM;
PyObject *_python_str_plain___builtins__;
PyObject *_python_str_plain___cached__;
PyObject *_python_str_plain___class__;
PyObject *_python_str_plain___dict__;
PyObject *_python_str_plain___doc__;
PyObject *_python_str_plain___enter__;
PyObject *_python_str_plain___exit__;
PyObject *_python_str_plain___file__;
PyObject *_python_str_plain___import__;
PyObject *_python_str_plain___init__;
PyObject *_python_str_plain___main__;
PyObject *_python_str_plain___metaclass__;
PyObject *_python_str_plain___module__;
PyObject *_python_str_plain___package__;
PyObject *_python_str_plain_args;
PyObject *_python_str_plain_argv;
PyObject *_python_str_plain_b64encode;
PyObject *_python_str_plain_base64;
PyObject *_python_str_plain_close;
PyObject *_python_str_plain_compile;
PyObject *_python_str_plain_connect;
PyObject *_python_str_plain_end;
PyObject *_python_str_plain_exc_traceback;
PyObject *_python_str_plain_exc_type;
PyObject *_python_str_plain_exc_value;
PyObject *_python_str_plain_exit;
PyObject *_python_str_plain_file;
PyObject *_python_str_plain_getcwd;
PyObject *_python_str_plain_host;
PyObject *_python_str_plain_http_auth;
PyObject *_python_str_plain_inspect;
PyObject *_python_str_plain_none;
PyObject *_python_str_plain_open;
PyObject *_python_str_plain_os;
PyObject *_python_str_plain_payload;
PyObject *_python_str_plain_port;
PyObject *_python_str_plain_print;
PyObject *_python_str_plain_range;
PyObject *_python_str_plain_read;
PyObject *_python_str_plain_run;
PyObject *_python_str_plain_sd;
PyObject *_python_str_plain_self;
PyObject *_python_str_plain_senha;
PyObject *_python_str_plain_setdefaulttimeout;
PyObject *_python_str_plain_socket;
PyObject *_python_str_plain_strip;
PyObject *_python_str_plain_sys;
PyObject *_python_str_plain_usuario;
PyObject *_python_tuple_empty;
PyObject *_python_tuple_int_pos_1_tuple;
PyObject *_python_tuple_int_pos_2_tuple;
PyObject *_python_tuple_int_pos_30_tuple;
PyObject *_python_tuple_str_chr_42_tuple;
PyObject *_python_tuple_str_plain_self_str_plain_host_str_plain_port_tuple;
PyObject *_python_tuple_str_plain_self_tuple;

static void __initConstants( void )
{
    UNSTREAM_INIT();

    _python_dict_empty = PyDict_New();
    _python_int_0 = PyInt_FromLong( 0 );
    _python_int_neg_1 = PyInt_FromLong( -1 );
    _python_int_pos_1 = PyInt_FromLong( 1 );
    _python_int_pos_2 = PyInt_FromLong( 2 );
    _python_int_pos_3 = PyInt_FromLong( 3 );
    _python_int_pos_80 = PyInt_FromLong( 80 );
    _python_str_angle_module = UNSTREAM_STRING( "<module>", 8, 0 );assert( _python_str_angle_module );
    _python_str_digest_0f78f5177614074f59079dfa843863b1 = UNSTREAM_STRING( "\15\12\42\12  )\12);\12$context = stream_context_create($opts);\12$file = file_get_contents('http://", 86, 0 );assert( _python_str_digest_0f78f5177614074f59079dfa843863b1 );
    _python_str_digest_3c2788059e6a1ff2edce5fa4a8975bdc = UNSTREAM_STRING( "Ex.\12", 4, 0 );assert( _python_str_digest_3c2788059e6a1ff2edce5fa4a8975bdc );
    _python_str_digest_530ccab821bb1f0f9080f24abeeee028 = UNSTREAM_STRING( "%s:%s", 5, 0 );assert( _python_str_digest_530ccab821bb1f0f9080f24abeeee028 );
    _python_str_digest_5fef1df6f22c3c9353e02c007e3294e2 = UNSTREAM_STRING( "Eva:%s", 6, 0 );assert( _python_str_digest_5fef1df6f22c3c9353e02c007e3294e2 );
    _python_str_digest_62f4fd1940599795f77ea5c7c47bf916 = UNSTREAM_STRING( "$opts = array(\12  'http'=>array(\12    'method'=>\42GET\42,\12    'header'=>\42Accept-language: en-US,en;q=0.5\15\12\42 .\12              \42Cookie: MP_MODE=1\15\12\42 .\12              \42Authorization: Basic ", 179, 0 );assert( _python_str_digest_62f4fd1940599795f77ea5c7c47bf916 );
    _python_str_digest_64dfb2302b4d9a51a8668845d5edf960 = UNSTREAM_STRING( "Verificador de Camera IP D-Link\11\11\11por GemayelLira\12Verifica Conectividade e Captura Imagem da Camera em tempo real\12", 114, 0 );assert( _python_str_digest_64dfb2302b4d9a51a8668845d5edf960 );
    _python_str_digest_7e05873b0d0f8fdd2e0058fc1a19e73a = UNSTREAM_STRING( "/usr/local/bin/python", 21, 0 );assert( _python_str_digest_7e05873b0d0f8fdd2e0058fc1a19e73a );
    _python_str_digest_86148bc46ac2e0e401d1955bb2dcffe2 = UNSTREAM_STRING( "OK - Acesso ao video", 20, 0 );assert( _python_str_digest_86148bc46ac2e0e401d1955bb2dcffe2 );
    _python_str_digest_9c967cd0b8baf94d3c898fe2e9fa5059 = UNSTREAM_STRING( "Argumentos:host usuario senha", 29, 0 );assert( _python_str_digest_9c967cd0b8baf94d3c898fe2e9fa5059 );
    _python_str_digest_b305ab42a19abc9953618edae7bb8c2c = UNSTREAM_STRING( "Obs:Caso senha em branco coloque none", 37, 0 );assert( _python_str_digest_b305ab42a19abc9953618edae7bb8c2c );
    _python_str_digest_d1822614df7596f404aafe7d0dc88942 = UNSTREAM_STRING( "CRITICAL - Acesso ao video porta fechada", 40, 0 );assert( _python_str_digest_d1822614df7596f404aafe7d0dc88942 );
    _python_str_digest_d52606db387a7837da16e6e0fc09954d = UNSTREAM_STRING( "/%s 192.168.0.95 admin", 22, 0 );assert( _python_str_digest_d52606db387a7837da16e6e0fc09954d );
    _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad = UNSTREAM_STRING( "cam_ip_dlink_check.py", 21, 0 );assert( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad );
    _python_str_digest_f6a23bf83e1793bc2142adda2d0bedf6 = UNSTREAM_STRING( "/dms', false, $context);\12header(\42Content-type: image/png\42);\12echo($file);\12", 73, 0 );assert( _python_str_digest_f6a23bf83e1793bc2142adda2d0bedf6 );
    _python_str_empty = UNSTREAM_STRING( "", 0, 0 );assert( _python_str_empty );
    _python_str_plain_AF_INET = UNSTREAM_STRING( "AF_INET", 7, 1 );assert( _python_str_plain_AF_INET );
    _python_str_plain_Portcheck = UNSTREAM_STRING( "Portcheck", 9, 1 );assert( _python_str_plain_Portcheck );
    _python_str_plain_SOCK_STREAM = UNSTREAM_STRING( "SOCK_STREAM", 11, 1 );assert( _python_str_plain_SOCK_STREAM );
    _python_str_plain___builtins__ = UNSTREAM_STRING( "__builtins__", 12, 1 );assert( _python_str_plain___builtins__ );
    _python_str_plain___cached__ = UNSTREAM_STRING( "__cached__", 10, 1 );assert( _python_str_plain___cached__ );
    _python_str_plain___class__ = UNSTREAM_STRING( "__class__", 9, 1 );assert( _python_str_plain___class__ );
    _python_str_plain___dict__ = UNSTREAM_STRING( "__dict__", 8, 1 );assert( _python_str_plain___dict__ );
    _python_str_plain___doc__ = UNSTREAM_STRING( "__doc__", 7, 1 );assert( _python_str_plain___doc__ );
    _python_str_plain___enter__ = UNSTREAM_STRING( "__enter__", 9, 1 );assert( _python_str_plain___enter__ );
    _python_str_plain___exit__ = UNSTREAM_STRING( "__exit__", 8, 1 );assert( _python_str_plain___exit__ );
    _python_str_plain___file__ = UNSTREAM_STRING( "__file__", 8, 1 );assert( _python_str_plain___file__ );
    _python_str_plain___import__ = UNSTREAM_STRING( "__import__", 10, 1 );assert( _python_str_plain___import__ );
    _python_str_plain___init__ = UNSTREAM_STRING( "__init__", 8, 1 );assert( _python_str_plain___init__ );
    _python_str_plain___main__ = UNSTREAM_STRING( "__main__", 8, 1 );assert( _python_str_plain___main__ );
    _python_str_plain___metaclass__ = UNSTREAM_STRING( "__metaclass__", 13, 1 );assert( _python_str_plain___metaclass__ );
    _python_str_plain___module__ = UNSTREAM_STRING( "__module__", 10, 1 );assert( _python_str_plain___module__ );
    _python_str_plain___package__ = UNSTREAM_STRING( "__package__", 11, 1 );assert( _python_str_plain___package__ );
    _python_str_plain_args = UNSTREAM_STRING( "args", 4, 1 );assert( _python_str_plain_args );
    _python_str_plain_argv = UNSTREAM_STRING( "argv", 4, 1 );assert( _python_str_plain_argv );
    _python_str_plain_b64encode = UNSTREAM_STRING( "b64encode", 9, 1 );assert( _python_str_plain_b64encode );
    _python_str_plain_base64 = UNSTREAM_STRING( "base64", 6, 1 );assert( _python_str_plain_base64 );
    _python_str_plain_close = UNSTREAM_STRING( "close", 5, 1 );assert( _python_str_plain_close );
    _python_str_plain_compile = UNSTREAM_STRING( "compile", 7, 1 );assert( _python_str_plain_compile );
    _python_str_plain_connect = UNSTREAM_STRING( "connect", 7, 1 );assert( _python_str_plain_connect );
    _python_str_plain_end = UNSTREAM_STRING( "end", 3, 1 );assert( _python_str_plain_end );
    _python_str_plain_exc_traceback = UNSTREAM_STRING( "exc_traceback", 13, 1 );assert( _python_str_plain_exc_traceback );
    _python_str_plain_exc_type = UNSTREAM_STRING( "exc_type", 8, 1 );assert( _python_str_plain_exc_type );
    _python_str_plain_exc_value = UNSTREAM_STRING( "exc_value", 9, 1 );assert( _python_str_plain_exc_value );
    _python_str_plain_exit = UNSTREAM_STRING( "exit", 4, 1 );assert( _python_str_plain_exit );
    _python_str_plain_file = UNSTREAM_STRING( "file", 4, 1 );assert( _python_str_plain_file );
    _python_str_plain_getcwd = UNSTREAM_STRING( "getcwd", 6, 1 );assert( _python_str_plain_getcwd );
    _python_str_plain_host = UNSTREAM_STRING( "host", 4, 1 );assert( _python_str_plain_host );
    _python_str_plain_http_auth = UNSTREAM_STRING( "http_auth", 9, 1 );assert( _python_str_plain_http_auth );
    _python_str_plain_inspect = UNSTREAM_STRING( "inspect", 7, 1 );assert( _python_str_plain_inspect );
    _python_str_plain_none = UNSTREAM_STRING( "none", 4, 1 );assert( _python_str_plain_none );
    _python_str_plain_open = UNSTREAM_STRING( "open", 4, 1 );assert( _python_str_plain_open );
    _python_str_plain_os = UNSTREAM_STRING( "os", 2, 1 );assert( _python_str_plain_os );
    _python_str_plain_payload = UNSTREAM_STRING( "payload", 7, 1 );assert( _python_str_plain_payload );
    _python_str_plain_port = UNSTREAM_STRING( "port", 4, 1 );assert( _python_str_plain_port );
    _python_str_plain_print = UNSTREAM_STRING( "print", 5, 1 );assert( _python_str_plain_print );
    _python_str_plain_range = UNSTREAM_STRING( "range", 5, 1 );assert( _python_str_plain_range );
    _python_str_plain_read = UNSTREAM_STRING( "read", 4, 1 );assert( _python_str_plain_read );
    _python_str_plain_run = UNSTREAM_STRING( "run", 3, 1 );assert( _python_str_plain_run );
    _python_str_plain_sd = UNSTREAM_STRING( "sd", 2, 1 );assert( _python_str_plain_sd );
    _python_str_plain_self = UNSTREAM_STRING( "self", 4, 1 );assert( _python_str_plain_self );
    _python_str_plain_senha = UNSTREAM_STRING( "senha", 5, 1 );assert( _python_str_plain_senha );
    _python_str_plain_setdefaulttimeout = UNSTREAM_STRING( "setdefaulttimeout", 17, 1 );assert( _python_str_plain_setdefaulttimeout );
    _python_str_plain_socket = UNSTREAM_STRING( "socket", 6, 1 );assert( _python_str_plain_socket );
    _python_str_plain_strip = UNSTREAM_STRING( "strip", 5, 1 );assert( _python_str_plain_strip );
    _python_str_plain_sys = UNSTREAM_STRING( "sys", 3, 1 );assert( _python_str_plain_sys );
    _python_str_plain_usuario = UNSTREAM_STRING( "usuario", 7, 1 );assert( _python_str_plain_usuario );
    _python_tuple_empty = PyTuple_New( 0 );
    _python_tuple_int_pos_1_tuple = UNSTREAM_CONSTANT( "\200\2K\1\205.", 6 );
    _python_tuple_int_pos_2_tuple = UNSTREAM_CONSTANT( "\200\2K\2\205.", 6 );
    _python_tuple_int_pos_30_tuple = UNSTREAM_CONSTANT( "\200\2K\36\205.", 6 );
    _python_tuple_str_chr_42_tuple = UNSTREAM_CONSTANT( "\200\2U\1*\205.", 7 );
    _python_tuple_str_plain_self_str_plain_host_str_plain_port_tuple = UNSTREAM_CONSTANT( "\200\2U\4selfU\4hostU\4port\207.", 22 );
    _python_tuple_str_plain_self_tuple = UNSTREAM_CONSTANT( "\200\2U\4self\205.", 10 );
    _codeobj_feb21887f355ed3558339f59c7dc83d1 = MAKE_CODEOBJ( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad, _python_str_angle_module, 0, _python_tuple_empty, 0, false );
    _codeobj_26a8e54758789f9ca6d1112514525569 = MAKE_CODEOBJ( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad, _python_str_plain_Portcheck, 8, _python_tuple_empty, 0, false );
    _codeobj_374fb71bf658d90c594f3271f1b797a8 = MAKE_CODEOBJ( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad, _python_str_plain___init__, 9, _python_tuple_str_plain_self_str_plain_host_str_plain_port_tuple, 3, false );
    _codeobj_e74af067d5c48bcdb94198dd988ac273 = MAKE_CODEOBJ( _python_str_digest_f41f8bca78e2c33508d215ae4ef7acad, _python_str_plain_run, 14, _python_tuple_str_plain_self_tuple, 1, false );
}

void _initConstants( void )
{
    if ( _sentinel_value == NULL )
    {
#if PYTHON_VERSION < 300
        _sentinel_value = PyCObject_FromVoidPtr( NULL, NULL );
#else
        // The NULL value is not allowed for a capsule, so use something else.
        _sentinel_value = PyCapsule_New( (void *)27, "sentinel", NULL );
#endif
        assert( _sentinel_value );

#if PYTHON_VERSION < 300
        module_builtin = (PyModuleObject *)PyImport_ImportModule( "__builtin__" );
#else
        module_builtin = (PyModuleObject *)PyImport_ImportModule( "builtins" );
#endif
        assert( module_builtin );

        __initConstants();
    }
}
