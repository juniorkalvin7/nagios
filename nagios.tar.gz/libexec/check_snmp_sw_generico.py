#!/usr/bin/env python
# -*- coding: utf-8 -*-

import commands, sys

if len(sys.argv) < 7:
  print 'CRITICAL - Favor digitar os parametros'
  print "Ex: %s community ip mib mensagem valor_warning valor_critical"%sys.argv[0]
  print 'Ex de mensagem: "Uso do cpu", "Uso de memória", "temperatura",uptime'
  sys.exit(2)
  
alarm = 0 
mib = sys.argv[3]
ip = sys.argv[2]
community = sys.argv[1]
op = sys.argv[4]
val_warning = int(sys.argv[5])
val_critical = int(sys.argv[6])


con = commands.getoutput('''/usr/bin/snmpwalk -v2c -c %s %s %s'''%(community, ip, mib))

simbolo = '%'

if "timeout" in str(con).lower():
  print "WARNING - Nao foi possivel acesso via snmp"
  sys.exit(1)

if op.lower().find('temperatura') != -1:
  simbolo = 'ºC'

try: 
  valor_de_uso_atual = int(str(con).split()[-1])
  valor_perf = valor_de_uso_atual
except:
  a = 1

if op.lower().find('uptime') != -1:
  simbolo = ''
#  print str(con).split()  
  valor_de_uso_atual = str(con).split()[4] + ' ' + str(con).split()[5] + ' ' + str(con).split()[6]
  valor_perf = int(str(con).split()[4])  
  
if op.lower().find('uptime') == -1:  
#  print valor_de_uso_atual
 # print val_warning
  #print  val_critical
  if int(valor_de_uso_atual) >= val_warning and int(valor_de_uso_atual) < val_critical :
    msg = "WARNING - "
    alarm = 1
  
  elif int(valor_de_uso_atual) >= val_critical:
    msg = "CRITICAL - "
    alarm = 2

  else:
    msg = "OK - "

  msg += "%s e de %s%s | valor_atual=%s "%(op,valor_de_uso_atual,simbolo,valor_perf)

else:
  #print 'aqui'
  msg = "OK - %s e de %s%s | valor_atual=%s "%(op,valor_de_uso_atual,simbolo,valor_perf) 
    
print msg      

sys.exit(alarm)

