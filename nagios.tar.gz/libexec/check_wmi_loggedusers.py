#!/usr/bin/python

import commands
import sys
import re

ip = sys.argv[1]
name = sys.argv[2]
senha = sys.argv[3]

sistema=0
dominio=0
#-----Dados da Classe Win32_LogonSession-----#
command_line1 = '/usr/bin/wmic -U %s%%%s //%s "select LogonId,LogonType from Win32_LogonSession" ' %(name,senha,ip)

status1, x = commands.getstatusoutput(command_line1)

x = x.replace('CLASS: Win32_LogonSession','')
x = x.replace('LogonId|LogonType','') #Id do Usuario--Tipo de Conexao

x = x.replace('|0','--Conta do Sistema')
x = x.replace('|2','--Terminal')
x = x.replace('|3','--Network')
x = x.replace('|4','--Batch')
x = x.replace('|5','--Service')
x = x.replace('|6','--Proxy')
x = x.replace('|7','--Unlock')
x = x.replace('|8','--NetworkCleartext')
x = x.replace('|9','--NewCredentials')
x = x.replace('|10','--Terminal Services')
x = x.replace('|11','--CachedInteractive')
x = x.replace('|12','--CachedRemoteInteractive')
x = x.replace('|13','--Cachedunlock')

x = x.replace('\n','--')
x = x.split('--')

while x.count(''):
	x.remove('')

#-----Dados da Classe Win32_LoggedOnUser-----#
command_line2 = '/usr/bin/wmic -U %s%%%s //%s "select Antecedent,Dependent from Win32_LoggedOnUser" ' %(name,senha,ip)

status2, y = commands.getstatusoutput(command_line2)

y = y.replace('CLASS: Win32_LoggedOnUser','')
y = y.replace('Antecedent|Dependent','')#'Dominio--Nome do Usuario--Id do Usuario
y = y.replace('\\\\.\\root\\cimv2:Win32_LogonSession.LogonId="','')
y = y.replace('\\\\.\\root\cimv2:Win32_Account.Domain=','')
y = y.replace('Name="','')
y = y.replace('"','')
y = y.replace('\n','|')
y = y.replace(',','|')
y = y.split('|')
#y = '--'.join(y)
#y = y.replace('|','--')

while y.count(''):
	y.remove('')


if status1 != 0 & status2 != 0:
        print "Problemas na obtencao de dados do host"
        sys.exit(1)


cont1 = 0
while cont1 < (len(x)-1):
	cont2 = 2
	while cont2 < (len(y)-2):
		if x[cont1] == y[cont2]:
			y[cont2] = "%s|%s" %(y[cont2],x[cont1 + 1])
		cont2 = cont2 + 3
	cont1 = cont1 + 2


cont2 = 2
while cont2 < (len(y)-2):
	if y[cont2].count('|') == 0:
		y[cont2] = "%s|null" %(y[cont2])	
	cont2 = cont2 + 3 


y = '|'.join(y)
y = y.split('|')



#-----Nome do host----#
command_line3 = '/usr/bin/wmic -U %s%%%s //%s "select Name from Win32_ComputerSystem" ' %(name,senha,ip)
status3, hostname  = commands.getstatusoutput(command_line3)

hostname = hostname.replace('CLASS: Win32_ComputerSystem','')
hostname = hostname.replace('Name','')
hostname = hostname.split('\n')

while hostname.count(''):
        hostname.remove('')

#''.join(hostname)


#-----CORPO FINAL-----#
corpo_final = """</table>
"""



#-----CORPO_LOCAL-----#
corpo_local = """
<table align="center" class="ListTable" >
<tr class="list_lvl_1"><TH colspan="4" style="background:#82CFD8"><b>LISTA DE USU&Aacute;RIOS LOGADOS NO SERVIDOR</b></TH></tr>
<tr class="list_lvl_1">
<TH>Dominio</TH>
<TH>Nome</TH>
<TH>Id</TH>
<TH>Tipo de conex&atilde;o</TH>
</tr>
"""

cont = 0
while cont < (len(y)-3):
	if (y[cont] == hostname[0]) & ((y[cont+3] == "Conta do Sistema") | (y[cont+3] == "Network")): 
        	corpo_local = corpo_local + '<tr align="Center"> <td>%s</td>              <td>%s</td>             <td>%s</td>		<td>%s</td></tr>' %(y[cont],y[cont+1],y[cont+2],y[cont+3])
	elif (y[cont] != hostname) & (y[cont+3] == "Terminal Services"):
		corpo_local = corpo_local + '<tr align="Center"> <td>%s</td>              <td>%s</td>             <td>%s</td>           <td>%s</td></tr>' %(y[cont],y[cont+1],y[cont+2],y[cont+3])
		sistema+=1
	cont = cont + 4


corpo_local = corpo_local + corpo_final



#-----CORPO_DOMINIO-----#
corpo_dominio = """
<table class="ListTable" align="center">
<tr class="list_lvl_1">
<TH colspan="4" style="background:#82CFD8"><b>LISTA DE USU&Aacute;RIOS LOGADOS NO DOMINIO</b></TH>
</tr>
<tr class="list_lvl_1">
<TH>Dominio</TH>
<TH>Nome</TH>
<TH>Id</TH>
<TH>Tipo de conex&atilde;o</TH>
</tr>
"""

controle_nomes = []
cont = 0

while cont < (len(y)-3):
	if (y[cont] != hostname[0]):
		if controle_nomes.count(y[cont+1]) == 0:
			dominio+=1
			controle_nomes.append(y[cont+1])
			corpo_dominio = corpo_dominio + '<tr align="Center"> <td>%s</td>              <td>%s</td>             <td>%s</td>		 <td>%s</td></tr>' %(y[cont],y[cont+1],y[cont+2],y[cont+3])
	cont = cont + 4

corpo_dominio = corpo_dominio + corpo_final 


if ((controle_nomes.count('Administrador')|(controle_nomes.count('Administrator'))) > 0):
	print "Atencao - Administrador conectado no Dominio total no sistema %d, no dominio %d|sistema=%d dominio=%d"%(sistema,dominio,sistema,dominio)
	print "%s\n%s" %(corpo_local.replace('\n',''),corpo_dominio.replace('\n',''))
	sys.exit(1)
else:	
	print "Lista de Usuarios Logados no Sistema %d, no Dominio %d|sistema=%d dominio=%d"%(sistema,dominio,sistema,dominio)
	

print "%s\n%s" %(corpo_local.replace('\n',''),corpo_dominio.replace('\n',''))
sys.exit(0)

