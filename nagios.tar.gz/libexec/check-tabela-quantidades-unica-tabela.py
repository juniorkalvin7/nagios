#!/usr/bin/env python 
# -*- coding: utf-8 -*-

import MySQLdb
import calendar
import datetime
import sys


saida = 0

def getTotalElementosGrupo(cliente):
  global saida
  
  try:
  #con2 = MySQLdb.connect(host='23.253.160.254', user='relatorio', passwd='W2bVC6oFZP',db='')
   con2 = MySQLdb.connect(host='127.0.0.1', user='relatorio', passwd='',db='')
  except:
    print 'CRITICAL - N?o foi poss?vel conectar com o banco do monitoramento. Favor verifique o usuario, senha e o nome do banco'
    sys.exit(2)
  
  arr_dentro = []
  con2 = con2.cursor()
  con2.execute("""select count(host_host_id)
  from centreon.hostgroup_relation  join centreon.host  
       on host_id = host_host_id
       where hostgroup_hg_id in (
             select hg_id from centreon.hostgroup
                    where hg_name = '%s' ) and host_activate = '1';"""%(cliente));
  arr_dentro = con2.fetchall()
  return int(str(arr_dentro[0]).replace("(","").replace("L,)",""))



def geraTabelaResumoQuantidades(cliente_consulta,completo):
  global saida	
  cliente_arr = cliente_consulta.split('-');
  somatorio = 0; 
 
  tabela_fixa = '''<table border="1" style="width:80%;margin-left:15%; margin-top:5%; border-collapse: separate;border-spacing: 0px 3px">'''
  tabela_fixa +='<tr><th colspan=9 style="text-align:center;">Tabela Fixa</th></tr>'
  tabela_fixa +='''<tr><th>Monitoramento Remoto (24x7) &#10; Segurança da Informação, &#10; Capacidade e &#10; Disponibilidade</th><th>Total(und) </th><th>SEMIT</th><th>CPL</th><th>SEMED</th><th>SEMAD</th><th>Dentro &#10; do &#10; Escopo</th><th>Fora &#10; do &#10; Escopo</th><th>Total Geral</th></tr>'''
  tabela_fixa +='<tr><td style="text-align:left; "><p> Servidor </p> </td><td style="text-align:center;"><p>75</p> </td><td style="text-align:center;"><p>52</p> </td><td style="text-align:center;"><p>8</p> </td><td style="text-align:center;"><p>13</p> </td><td style="text-align:center;"><p>2</p> </td><td style="text-align:center;"><p> 75 </p> </td><td style="text-align:center;"><p> 115 </p> </td><td style="text-align:center;"><p>190</p> </td></tr>' 
  tabela_fixa +='<tr><td style="text-align:left;"><p>Ativos de Rede &#10; Energia(Roteadores e switches, &#10; Nobreaks, Modens e &#10; Rádios)</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p> - </p> </td><td style="text-align:center;"><p> - </p> </td><td style="text-align:center;"><p>-</p> </td></tr>' 
  tabela_fixa +='<tr><td style="text-align:left; "><p> Roteador </p> </td><td style="text-align:center;"><p>42</p> </td><td style="text-align:center;"><p>42</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p> 42 </p> </td><td style="text-align:center;"><p> 2 </p> </td><td style="text-align:center;"><p>44</p> </td></tr>' 
  tabela_fixa +='<tr><td style="text-align:left;"><p> Switch e NoBreak </p> </td><td style="text-align:center;"><p>59</p> </td><td style="text-align:center;"><p>51</p> </td><td style="text-align:center;"><p>3</p> </td><td style="text-align:center;"><p>5</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p> 59 </p> </td><td style="text-align:center;"><p> 8 </p> </td><td style="text-align:center;"><p>67</p> </td></tr>'
  tabela_fixa +='<tr><td style="text-align:left; "><p> Radio </p> </td><td style="text-align:center;"><p>26</p> </td><td style="text-align:center;"><p>26</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p> 26 </p> </td><td style="text-align:center;"><p> - </p> </td><td style="text-align:center;"><p>26</p> </td></tr>'
  tabela_fixa +='<tr><td style="text-align:left;"><p> Outros </p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p>-</p> </td><td style="text-align:center;"><p> - </p> </td><td style="text-align:center;"><p> 13 </p> </td><td style="text-align:center;"><p>13</p> </td></tr>'
  tabela_fixa +='<tr><td style="text-align:left; "><p> Total </p> </td><td style="text-align:center;"><p>202</p> </td><td style="text-align:center;"><p>172</p> </td><td style="text-align:center;"><p>11</p> </td><td style="text-align:center;"><p>18</p> </td><td style="text-align:center;"><p>2</p> </td><td style="text-align:center;"><p>202</p> </td><td style="text-align:center;"><p>138</p> </td><td style="text-align:center;"><p>340</p> </td></tr></table>'

  
  table = "";
  cabecalho_tabela = '<table border="1" style="width:80%;margin-left:15%; margin-top:5%; border-collapse: separate;border-spacing: 0px 3px;"> <tbody border="1" style="width:70%;">';
  tamanho_fonte_titulo ='110%';
  tam_font = "10pt";
  
  titulo = cliente_consulta;
  if(cliente_consulta == "SEMIT" and completo == "completo"):
    titulo = titulo.replace("SEMIT","PMSL");
    titulo = "SEMIT"
  elif(cliente_consulta == "SEMIT" and completo == ""):
    titulo = cliente_consulta;
    titulo = "PMSL"
  else: titulo = titulo.replace("SEMIT","PMSL") ; 
  
  cabecalho = '''<tr><th colspan=9 style="text-align:center;">Tabela Alimentada pelo BD</th></tr><tr><th>Monitoramento Remoto (24x7) &#10; Segurança da Informação, &#10; Capacidade e &#10; Disponibilidade</th><th>Total(und)</th><th>SEMIT</th><th>CPL</th><th>SEMED</th><th>SEMAD</th><th>Dentro &#10; do &#10; Escopo</th><th>Fora &#10; do &#10; Escopo</th><th>Total Geral</th></tr>''';

  string_tabela = "";
  string_tabela += '<tr>';
  valor_fora_escopo = 0;
  somatorio_fora_escopo = 0;
  
  # TIPO: Servidor
  string_tabela += '<td border="1" style="text-align:left;"><p> Servidor </p> </td>';
  valor = getTotalElementosGrupo(cliente_consulta+"-CONTRATADO-SERVIDORES");
  valor_fora_escopo = 0;
  
  valor_fora_escopo = 115;
  #valor_fora_escopo = valor_semit = getTotalElementosGrupo("SEMIT-FORA-ESCOPO-SERVIDORES");
  
  somatorio_semit = 0
  somatorio_cpl = 0
  somatorio_semed = 0
  somatorio_semad = 0
  
  valor_semit = getTotalElementosGrupo("SEMIT-CONTRATADO-SERVIDORES");
  valor_cpl = getTotalElementosGrupo("CPL-CONTRATADO-SERVIDORES");
  valor_semed = getTotalElementosGrupo("SEMED-CONTRATADO-SERVIDORES");
  valor_semad = getTotalElementosGrupo("SEMAD-CONTRATADO-SERVIDORES");
  perf_data = ""
  perf_data = '| semit_servidores=%s cpl_servidores=%s semed_servidores=%s semed_semad=%s '   
  
  
  somatorio_semit += valor_semit
  somatorio_cpl += valor_cpl
  somatorio_semed += valor_semed
  somatorio_semad += valor_semad
  
  somatorio_fora_escopo += valor_fora_escopo;
  # somatorio += valor;
  valor_parcial = valor_semit + valor_cpl + valor_semed + valor_semad; 
  somatorio += valor_parcial;
  
  perf_data = '| total-hs-servidores=%s semit_servidores=%s cpl_servidores=%s semed_servidores=%s semed_semad=%s dentro-escopo-servidores=%s fora-escopo-servidores=%s total-geral-servidores=%s'%(valor_parcial,valor_semit,valor_cpl,valor_semed,valor_semad,valor_parcial,valor_fora_escopo, (valor_parcial + valor_fora_escopo));
  
  azul = "#17E9CD"
  vermelho = "#FC465E"
  cor = "#ffffff"
  
  valor_tabela_fixa = [75,52,8,13,2,75,115,190]
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[0]:
    cor = azul
    saida = 1
  elif valor_parcial < valor_tabela_fixa[0]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_parcial)[valor_parcial > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semit > valor_tabela_fixa[1]:
    cor = azul
    saida = 1
  elif valor_semit < valor_tabela_fixa[1]:
    cor = vermelho
    saida = 1
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semit)[valor_semit > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_cpl > valor_tabela_fixa[2]:
    saida = 1
    cor = azul
  elif valor_cpl < valor_tabela_fixa[2]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_cpl)[valor_cpl > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semed > valor_tabela_fixa[3]:
    saida = 1
    cor = azul
  elif valor_semed < valor_tabela_fixa[3]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semed)[valor_semed > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semad > valor_tabela_fixa[4]:
    saida = 1
    cor = azul
  elif valor_semad < valor_tabela_fixa[4]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semad)[valor_semad > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[5]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[5]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_parcial)[valor_parcial > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if valor_fora_escopo > valor_tabela_fixa[6]:
    saida = 1
    cor = azul
  elif valor_fora_escopo < valor_tabela_fixa[6]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if (valor_parcial + valor_fora_escopo) > valor_tabela_fixa[7]:
    saida = 1
    cor = azul
  elif (valor_parcial + valor_fora_escopo) < valor_tabela_fixa[7]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>' + str(('-',valor_parcial + valor_fora_escopo)[(valor_parcial + valor_fora_escopo) > 0]) + '</p> </td>';
                
  string_tabela += '</tr>';
  #FIM Tipo: Servidor
  
  # tipo tabela vazia ativos de redes energia(roteadores e switches, NoBreaks, Modens e radios)
  string_tabela += '<tr>';
  string_tabela += '<td style="text-align:left;"><p>Ativos de Rede &#10; Energia(Roteadores e switches, &#10; Nobreaks, Modens e &#10; Rádios)</p> </td>';
  string_tabela += '<td style="text-align:center;"><p>'+ str('-') +'</p> </td>';
  string_tabela += '<td style="text-align:center;"><p>'+ str('-') +'</p> </td>';
  string_tabela += '<td style="text-align:center;"><p>'+ str('-') +'</p> </td>';
  string_tabela += '<td style="text-align:center;"><p>'+ str('-') +'</p> </td>';
  string_tabela += '<td style="text-align:center;"><p>'+ str('-') +'</p> </td>';
  string_tabela += '<td style="text-align:center;"><p> ' + str('-') + ' </p> </td>';
  string_tabela += '<td style="text-align:center;"><p> ' +str('-') + ' </p> </td>';
  string_tabela += '<td style="text-align:center;"><p>' + str('-') + '</p> </td>';
  # FIM tipo tabela vazia ativos de redes energia(roteadores e switches, NoBreaks, Modens e radios)
  
  
  # TIPO: Roteador
  string_tabela += '<tr>';
  
  string_tabela += '<td style="text-align:left; "><p> Roteador </p> </td>';    
  valor_fora_escopo = 2;
  #valor_fora_escopo = valor_semit = getTotalElementosGrupo("SEMIT-FORA-ESCOPO-ROTEADORES");
  
  valor_semit = getTotalElementosGrupo("SEMIT-CONTRATADO-ROTEADORES");
  valor_cpl = getTotalElementosGrupo("CPL-CONTRATADO-ROTEADORES");
  valor_semed = getTotalElementosGrupo("SEMED-CONTRATADO-ROTEADORES");
  valor_semad = getTotalElementosGrupo("SEMAD-CONTRATADO-ROTEADORES");
  
  somatorio_semit += valor_semit
  somatorio_cpl += valor_cpl
  somatorio_semed += valor_semed
  somatorio_semad += valor_semad
  
  somatorio_fora_escopo += valor_fora_escopo;
  # somatorio += valor;
  valor_parcial = valor_semit + valor_cpl + valor_semed + valor_semad;
  # valor_parcial = 42; 
  somatorio += valor_parcial;
  
  perf_data += ' total-hs-roteadores=%s semit_roteadores=%s cpl_roteadores=%s semed_roteadores=%s semed_semad=%s dentro-escopo-roteadores=%s fora-escopo-roteadores=%s total-geral-roteadores=%s'%(valor_parcial,valor_semit,valor_cpl,valor_semed,valor_semad,valor_parcial,valor_fora_escopo, (valor_parcial + valor_fora_escopo));
  
  valor_tabela_fixa = [42,42,0,0,0,42,2,44]
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[0]:
    cor = azul
    saida = 1
  elif valor_parcial < valor_tabela_fixa[0]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_parcial)[valor_parcial > 0]) +'</p> </td>';
  # string_tabela += '<td style="text-align:center;"><p>'+ str(42) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semit > valor_tabela_fixa[1]:
    saida = 1
    cor = azul
  elif valor_semit < valor_tabela_fixa[1]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semit)[valor_semit > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_cpl > valor_tabela_fixa[2]:
    saida = 1
    cor = azul
  elif valor_cpl < valor_tabela_fixa[2]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_cpl)[valor_cpl > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semed > valor_tabela_fixa[3]:
    saida = 1
    cor = azul
  elif valor_semed < valor_tabela_fixa[3]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semed)[valor_semed > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semad > valor_tabela_fixa[4]:
    saida = 1
    cor = azul
  elif valor_semad < valor_tabela_fixa[4]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semad)[valor_semad > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[5]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[5]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_parcial)[valor_parcial > 0]) + ' </p> </td>';
  # string_tabela += '<td style="text-align:center;"><p> ' + str(42) + ' </p> </td>';
  
  cor = "#ffffff"
  if valor_fora_escopo > valor_tabela_fixa[6]:
    saida = 1
    cor = azul
  elif valor_fora_escopo < valor_tabela_fixa[6]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if (valor_parcial + valor_fora_escopo) > valor_tabela_fixa[7]:
    saida = 1
    cor = azul
  elif (valor_parcial + valor_fora_escopo) < valor_tabela_fixa[7]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>' + str(('-',valor_parcial + valor_fora_escopo)[(valor_parcial + valor_fora_escopo) > 0]) + '</p> </td>';
       
  string_tabela += '</tr>'; 
 #FIM Tipo: Roteador
  
  
  # TIPO: Swhitch e NoBreak
  string_tabela += '<tr>';
  string_tabela += '<td style="text-align:left;"><p> Switch e NoBreak </p> </td>';
  valor_fora_escopo = 8;
  #valor_fora_escopo = valor_semit = getTotalElementosGrupo("SEMIT-FORA-SWITCH-NOBREACK");
  
  valor_semit = getTotalElementosGrupo("SEMIT-CONTRATADO-SWITCH-NOBREACK");
  valor_cpl = getTotalElementosGrupo("CPL-CONTRATADO-SWITCH-NOBREACK");
  valor_semed = getTotalElementosGrupo("SEMED-CONTRATADO-SWITCH-NOBREACK");
  valor_semad = getTotalElementosGrupo("SEMAD-CONTRATADO-SWITCH-NOBREACK");
  
  somatorio_semit += valor_semit
  somatorio_cpl += valor_cpl
  somatorio_semed += valor_semed
  somatorio_semad += valor_semad
  
  somatorio_fora_escopo += valor_fora_escopo;
  # somatorio += valor;
  valor_parcial = valor_semit + valor_cpl + valor_semed + valor_semad;
  # valor_parcial = 59; 
  somatorio += valor_parcial;
  
  perf_data += ' total-hs-switch-no-break=%s semit_switch-no-break=%s cpl_switch-no-break=%s semed_switch-no-break=%s semed_semad=%s dentro-escopo-switch-no-break=%s fora-escopo-switch-no-break=%s total-geral-switch-no-break=%s'%(valor_parcial,valor_semit,valor_cpl,valor_semed,valor_semad,valor_parcial,valor_fora_escopo, (valor_parcial + valor_fora_escopo));
  
  valor_tabela_fixa = [59,51,3,5,0,59,8,67]
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[0]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[0]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td style="text-align:center;"><p>'+ str(('-',valor_parcial)[valor_parcial > 0]) +'</p> </td>';
  
  # string_tabela += '<td style="text-align:center;"><p>'+ str(59) +'</p> </td>';
  cor = "#ffffff"
  if valor_semit > valor_tabela_fixa[1]:
    saida = 1
    cor = azul
  elif valor_semit < valor_tabela_fixa[1]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semit)[valor_semit > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_cpl > valor_tabela_fixa[2]:
    saida = 1
    cor = azul
  elif valor_cpl < valor_tabela_fixa[2]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_cpl)[valor_cpl > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semed > valor_tabela_fixa[3]:
    saida = 1
    cor = azul
  elif valor_semed < valor_tabela_fixa[3]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semed)[valor_semed > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semad > valor_tabela_fixa[4]:
    saida = 1
    cor = azul
  elif valor_semad < valor_tabela_fixa[4]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semad)[valor_semad > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[5]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[5]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_parcial)[valor_parcial > 0])  + ' </p> </td>';
  
  cor = "#ffffff"
  if valor_fora_escopo > valor_tabela_fixa[6]:
    saida = 1
    cor = azul
  elif valor_fora_escopo < valor_tabela_fixa[6]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if (valor_parcial + valor_fora_escopo) > valor_tabela_fixa[7]:
    saida = 1
    cor = azul
  elif (valor_parcial + valor_fora_escopo) < valor_tabela_fixa[7]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>' + str(('-',valor_parcial + valor_fora_escopo)[(valor_parcial + valor_fora_escopo) > 0]) + '</p> </td>';
  
  string_tabela += '</tr>';
 #FIM Tipo: Swhitch e NoBreak
        
        
  # TIPO: Radio
  string_tabela += '<tr>';
  string_tabela += '<td style="text-align:left; "><p> Radio </p> </td>';
   
  valor_fora_escopo = 0;
  #valor_fora_escopo = valor_semit = getTotalElementosGrupo("SEMIT-FORA-RADIOS");
  
  valor_semit = getTotalElementosGrupo("SEMIT-CONTRATADO-RADIOS");
  valor_cpl = getTotalElementosGrupo("CPL-CONTRATADO-RADIOS");
  valor_semed = getTotalElementosGrupo("SEMED-CONTRATADO-RADIOS");
  valor_semad = getTotalElementosGrupo("SEMAD-CONTRATADO-RADIOS");
  
  somatorio_semit += valor_semit
  somatorio_cpl += valor_cpl
  somatorio_semed += valor_semed
  somatorio_semad += valor_semad
  
  somatorio_fora_escopo += valor_fora_escopo;
  # somatorio += valor;
  valor_parcial = valor_semit + valor_cpl + valor_semed + valor_semad; 
  somatorio += valor_semit + valor_cpl + valor_semed + valor_semad;
  
  perf_data += ' total-hs-radios=%s semit_radios=%s cpl_radios=%s semed_radios=%s semed_semad=%s dentro-escopo-radios=%s fora-escopo-radios=%s total-geral-radios=%s'%(valor_parcial,valor_semit,valor_cpl,valor_semed,valor_semad,valor_parcial,valor_fora_escopo, (valor_parcial + valor_fora_escopo));
  
  
  valor_tabela_fixa = [26,26,0,0,0,26,0,26]
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[0]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[0]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_parcial)[valor_parcial > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semit > valor_tabela_fixa[1]:
    saida = 1
    cor = azul
  elif valor_semit < valor_tabela_fixa[1]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semit)[valor_semit > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_cpl > valor_tabela_fixa[2]:
    saida = 1
    cor = azul
  elif valor_cpl < valor_tabela_fixa[2]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_cpl)[valor_cpl > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semed > valor_tabela_fixa[3]:
    saida = 1
    cor = azul
  elif valor_semed < valor_tabela_fixa[3]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semed)[valor_semed > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semad > valor_tabela_fixa[4]:
    saida = 1
    cor = azul
  elif valor_semad < valor_tabela_fixa[4]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semad)[valor_semad > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[5]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[5]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_parcial)[valor_parcial > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if valor_fora_escopo > valor_tabela_fixa[6]:
    saida = 1
    cor = azul
  elif valor_fora_escopo < valor_tabela_fixa[6]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if (valor_parcial + valor_fora_escopo) > valor_tabela_fixa[7]:
    saida = 1
    cor = azul
  elif (valor_parcial + valor_fora_escopo) < valor_tabela_fixa[7]:
    saida = 1
    cor = vermelho  
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>' + str(('-',valor_parcial + valor_fora_escopo)[(valor_parcial + valor_fora_escopo) > 0]) + '</p> </td>';
    
  string_tabela += '</tr>';
  #FIM Tipo: Radio
      
      
  # TIPO: Outros
  string_tabela += '<tr>';
  string_tabela += '<td style="text-align:left;"><p> Outros </p> </td>';
  valor_fora_escopo = 13;
  #valor_fora_escopo = valor_semit = getTotalElementosGrupo("SEMIT-FORA-OUTROS");
  
  valor_semit = getTotalElementosGrupo("SEMIT-CONTRATADO-OUTROS");
  valor_cpl = getTotalElementosGrupo("CPL-CONTRATADO-OUTROS");
  valor_semed = getTotalElementosGrupo("SEMED-CONTRATADO-OUTROS");
  valor_semad = getTotalElementosGrupo("SEMAD-CONTRATADO-OUTROS");
  
  
  
  # Comentado para n?o somar com o outros
  # somatorio += valor;
  # Valor ta recebendo 0 pra n?o entrar na contagem
  # do dentro do escopo, s? na contagem dos fora
  valor = 0;
  
  # valor_semit = 0
  # valor_cpl = 0
  # valor_semed = 0
  # valor_semad = 0
  
  somatorio_semit += valor_semit
  somatorio_cpl += valor_cpl
  somatorio_semed += valor_semed
  somatorio_semad += valor_semad
  
  somatorio_fora_escopo += valor_fora_escopo;
  # somatorio += valor;
  valor_parcial = valor_semit + valor_cpl + valor_semed + valor_semad; 
  somatorio += valor_semit + valor_cpl + valor_semed + valor_semad;
  
  perf_data += ' total-hs-outros=%s semit_outros=%s cpl_outros=%s semed_outros=%s semed_semad=%s dentro-escopo-outros=%s fora-escopo-outros=%s total-geral-outros=%s'%(valor_parcial,valor_semit,valor_cpl,valor_semed,valor_semad,valor_parcial,valor_fora_escopo, (valor_parcial + valor_fora_escopo));
  
  
  valor_tabela_fixa = [0,0,0,0,0,0,13,13]
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[0]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[0]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_parcial)[valor_parcial > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semit > valor_tabela_fixa[1]:
    saida = 1
    cor = azul
  elif valor_semit < valor_tabela_fixa[1]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semit)[valor_semit > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_cpl > valor_tabela_fixa[2]:
    saida = 1
    cor = azul
  elif valor_cpl < valor_tabela_fixa[2]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_cpl)[valor_cpl > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semed > valor_tabela_fixa[3]:
    saida = 1
    cor = azul
  elif valor_semed < valor_tabela_fixa[3]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semed)[valor_semed > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_semad > valor_tabela_fixa[4]:
    saida = 1
    cor = azul
  elif valor_semad < valor_tabela_fixa[4]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',valor_semad)[valor_semad > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if valor_parcial > valor_tabela_fixa[5]:
    saida = 1
    cor = azul
  elif valor_parcial < valor_tabela_fixa[5]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_parcial)[valor_parcial > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if valor_fora_escopo > valor_tabela_fixa[6]:
    saida = 1
    cor = azul
  elif valor_fora_escopo < valor_tabela_fixa[6]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p> ' + str(('-',valor_fora_escopo)[valor_fora_escopo > 0]) + ' </p> </td>';
  
  cor = "#ffffff"
  if (valor_parcial + valor_fora_escopo) > valor_tabela_fixa[7]:
    saida = 1
    cor = azul
  elif (valor_parcial + valor_fora_escopo) < valor_tabela_fixa[7]:
    saida = 1
    cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>' + str(('-',valor_parcial + valor_fora_escopo)[(valor_parcial + valor_fora_escopo) > 0]) + '</p> </td>';

  string_tabela += '</tr>';
 #FIM Tipo: Outros
      
      
  # TIPO: Somatorio total
  valor_tabela_fixa = [202,172,11,18,2,202,138,340]
  
  string_tabela += '<tr>';
  
  string_tabela += '<td style="text-align:left; "><p> Total </p> </td>';
  
  cor = "#ffffff"
  if somatorio > valor_tabela_fixa[0]: cor = azul
  elif somatorio < valor_tabela_fixa[0]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio_semit > valor_tabela_fixa[1]: cor = azul
  elif somatorio_semit < valor_tabela_fixa[1]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio_semit) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio_cpl > valor_tabela_fixa[2]: cor = azul
  elif somatorio_cpl < valor_tabela_fixa[2]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio_cpl) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio_semed > valor_tabela_fixa[3]: cor = azul
  elif somatorio_semed < valor_tabela_fixa[3]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio_semed) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio_semad > valor_tabela_fixa[4]: cor = azul
  elif somatorio_semad < valor_tabela_fixa[4]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio_semad) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio > valor_tabela_fixa[5]: cor = azul
  elif somatorio < valor_tabela_fixa[5]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(somatorio) +'</p> </td>';
  
  cor = "#ffffff"
  if somatorio_fora_escopo > valor_tabela_fixa[6]: cor = azul
  elif somatorio_fora_escopo < valor_tabela_fixa[6]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',somatorio_fora_escopo)[somatorio_fora_escopo > 0]) +'</p> </td>';
  
  cor = "#ffffff"
  if (somatorio + somatorio_fora_escopo) > valor_tabela_fixa[7]: cor = azul
  elif (somatorio + somatorio_fora_escopo) < valor_tabela_fixa[7]: cor = vermelho
  string_tabela += '<td bgcolor="'+ cor +'" style="text-align:center;"><p>'+ str(('-',(somatorio + somatorio_fora_escopo))[(somatorio + somatorio_fora_escopo) > 0]) +'</p> </td>';
  # FIM Tipo: Somatorio total
      
      
  string_tabela += '</tr>';
  
  table = string_tabela;
  table = cabecalho_tabela + cabecalho + table + '</table>'
  table = table.replace('\n','').replace('<br>','').replace('</br>','');
  #table = table.replace('&#10;','').replace('<br>','')
  
  return tabela_fixa + ' &#10; ' + table


args = sys.argv[1::]
if len(sys.argv) < 2:
  print 'CRITICAL - Por favor insira o(s) par?metro(s)'
  sys.exit(2)

#print args
#nome_cliente = args[0]
#cliente = "SEMIT-NAO-CONTRATADO";
#arr_clientes = ["SEMIT", "SEMIT", "CPL", "SEMED", "SEMAD"]

#arr_clientes = ["SEMIT"]
arr_clientes = [sys.argv[1]]
tabela = ""
completo = "completo"
if sys.argv[1] == "PMSL":
#  print 'aqui'
  arr_clientes = []
  arr_clientes = ["SEMIT"]
  completo = ""
for cliente in arr_clientes:
  if cliente == "SEMIT" and completo == "completo" :
    tabela += geraTabelaResumoQuantidades(cliente,"completo") + ""
    completo = ""
  else:
    tabela += geraTabelaResumoQuantidades(cliente,"") + ""
if saida == 1:
  print "WARNING - Tabelas com valores diferentes."
else:
  print "OK - Tabelas de resumo."
print tabela;

sys.exit(saida)
#alo