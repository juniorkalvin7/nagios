#!/usr/bin/python
# -*- coding: utf-8 -*-

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email import Encoders
import os,sys,getopt,datetime,re
import logging
import socket
"""
$USER1$/smart-mail.py \
-a 1 \
-b mail.fromti.com.br \
-c "cmp.semit@fromti.com.br" \
-d peefMorb \
-e "suporte@intechne.com.br" \
-f "$HOSTSTATE$" \
-g "$NOTIFICATIONTYPE$" \
-h "$HOSTNAME$" \
-i "$SERVICEDESC$" \
-j "$SERVICESTATE$" \
-k "$SERVICEOUTPUT$" \
-l "$HOSTOUTPUT$" \
-m "$HOSTADDRESS$" \
-n "$LONGSERVICEOUTPUT$" \
-o "$LASTSERVICECHECK$" \
-p "$LASTHOSTCHECK$"

./smart-mail.py \
-a 1 \
-b mail.fromti.com.br \
-c "cmp.semit@fromti.com.br" \
-d peefMorb \
-e "suporte@intechne.com.br" \
-f "$HOSTSTATE$" \
-g "$NOTIFICATIONTYPE$" \
-h "$HOSTNAME$" \
-i "$SERVICEDESC$" \
-j "$SERVICESTATE$" \
-k "$SERVICEOUTPUT$" \
-l "$HOSTOUTPUT$" \
-m "$HOSTADDRESS$" \
-n "$LONGSERVICEOUTPUT$" \
-o "$LASTSERVICECHECK$" \
-p "$LASTHOSTCHECK$"

teste mensages
crit in semit 
/usr/bin/python /usr/local/nagios/libexec/smart-mail.py -a 1 -b mail.fromti.com.br -c cmp.semit@fromti.com.br -d peefMorb -e suporte@intechne.com.br -f UP -g PROBLEM -h fs-prod-cpl-01 -i Disponibilidade -j CRITICAL -k "CRITICAL - 192.168.56.3: rta 2658.163ms, lost 0%" -l "PING WARNING - Packet loss = 75%, RTA = 3293.94 ms" -m 192.168.56.3 -n  -o 1435859731 -p 1435859615 -q ""

"""

def seconds_to_dhms(seconds):
  days = seconds // (3600 * 24)
  hours = (seconds // 3600) % 24
  minutes = (seconds // 60) % 60
  seconds = seconds % 60
  return days, hours, minutes, seconds

def mail(IPSMTPSRV, USERMAIL, SENHAMAIL,subject,text,tlsvar,to):
  #to='suporte@intechne.com.br'
  #to='samuel@intechne.com.br'
  if ':' in to:
    toto = to.split(':')
    for to in toto:
      try:
        msg = MIMEMultipart()
        msg['From'] = USERMAIL
        msg['To'] = to
        msg['Subject'] = subject
        msg["Content-type"] = "text/html"
        msg.attach(MIMEText(text,'html'))
        mailServer = smtplib.SMTP(IPSMTPSRV, 25)
        mailServer.ehlo()
        if tlsvar=='1':
          mailServer.starttls()
          mailServer.ehlo()
        mailServer.login(USERMAIL, SENHAMAIL)
        mailServer.sendmail(USERMAIL, to, msg.as_string())
        mailServer.close()
        logging.info("%s %s"%(to,subject))
      except Exception,e:
        logging.info("%s %s erro:%s"%(to,subject,e))

  else:
    to=to
    try:
      msg = MIMEMultipart()
      msg['From'] = USERMAIL
      msg['To'] = to
      msg['Subject'] = subject
      msg["Content-type"] = "text/html"
      msg.attach(MIMEText(text,'html'))
      mailServer = smtplib.SMTP(IPSMTPSRV, 25)
      mailServer.ehlo()
      if tlsvar=='1':
        mailServer.starttls()
        mailServer.ehlo()
      mailServer.login(USERMAIL, SENHAMAIL)
      mailServer.sendmail(USERMAIL, to, msg.as_string())
      mailServer.close()
      logging.info("%s %s"%(to,subject))
    except Exception,e:
      logging.info("%s %s erro:%s"%(to,subject,e))
  
  
def usage():
  print """Modo de uso 
python smart-mail.py
  -a 1 or 0 se o servidor usa autenticacao tls
  -b $IPSMTPSRV ip do servidor de email
  -c $USERMAIL usuario do email
  -d $SENHAMAIL senha do email
  -e $email da pessoa
  -f $HOSTSTATE$ variavelis abaixo sao do NAGIOS
  -g "$NOTIFICATIONTYPE$" 
  -h "$HOSTNAME$" 
  -i "$SERVICEDESC$" 
  -j "$SERVICESTATE$" 
  -k "$SERVICEOUTPUT$" 
  -l "$HOSTOUTPUT$" 
  -m "$HOSTADDRESS$" 
  -n "$HOSTOUTPUT$" 
  -o "$LONGSERVICEOUTPUT$"
  -p "$LASTSERVICECHECK$" 
"""
#print len(sys.argv)
#if not len(sys.argv) == 23:
  #usage()
  #sys.exit()


if os.path.isfile("msg-custom"):
  msg_custom_file="msg-custom"
elif os.path.isfile("/usr/local/nagios/libexec/msg-custom"):
  msg_custom_file="/usr/local/nagios/libexec/msg-custom"
else:
  print "Erro nao consegui localiza arquivo msg-custom"
  sys.exit(2)

try:
  cliente=socket.gethostname()
except Exception,e:
  print "Erro nao consegui capturar hostname ,",e
  sys.exit(1)
clients=[["semit","semit"],
         ["maciel","maciel"],
         ["jmontello","jomntello"],
         ["udi","udi"],
         ["cmp-prod-fromti-01","Central"]
         ]
ok=0
for x in clients:
  if x[0] in cliente.lower():
    cliente=x[1].upper()
    ok=1
    break
if ok==0:
  cliente="desconhecido"

try:
  options = getopt.getopt(sys.argv[1:], 'a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p')[0]
except getopt.GetoptError, err:
  print err
  usage()
  sys.exit()
  
for option, value in options:
  print option,value
  if option == '-a':tlsvar            = value
  if option == '-b':IPSMTPSRV         = value
  if option == '-c':USERMAIL          = value
  if option == '-d':SENHAMAIL         = value      
  if option == '-e':to                = value      
  if option == '-f':HOSTSTATE         = value
  if option == '-g':NOTIFICATIONTYPE  = value
  if option == '-h':HOSTNAME          = value
  if option == '-i':SERVICEDESC       = value
  if option == '-j':SERVICESTATE      = value
  if option == '-k':SERVICEOUTPUT     = value  
  if option == '-l':HOSTADDRESS       = value
  if option == '-m':HOSTOUTPUT        = value
  if option == '-n':LONGSERVICEOUTPUT = value
  if option == '-o':LASTSERVICECHECK  = value
  if option == '-p':SHORTDATETIME     = value
  #print option,value
#sys.exit(1)
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(message)s',
                    filename='/tmp/notify.mail.log',
                    filemode='a')
#logging.info("sync master mode long")

pluginspath='/var/lib/centreon/centplugins/'

#Custom messages reader in
#tmp=open('/usr/local/nagios/libexec/msg-custom','r').read()

tmp=open(msg_custom_file,'r').read()
#print msgs_custom
msgs_custom={}
cont1=0
while 1:		
  try:
    inicio = tmp.index('{') + 1
    fim = tmp.index('}')
  except:break
  msgdata = tmp[inicio:fim]
  string=msgdata.split('\n')[0].replace('strings=','')
  strings=string.split(';')  
  alerta=msgdata.split('\n')[1].replace('Alerta=','')
  causas=msgdata.split('\n')[2].replace('Causas=','')
  restore=msgdata.split('\n')[3].replace('Restore=','')
  msgs_custom[cont1]=[strings,alerta,causas,restore]
  cont1 +=1	
  tmp = tmp[fim + 1:]

#print msgs_custom
#print "SERVICEOUTPUT",SERVICEOUTPUT
for x in msgs_custom:
  teve=0
  for xx in msgs_custom[x][0]:
    #print "verificando ",xx
    if ',' in xx and '[' in xx:
      for xxx in xx.replace('[','').replace(']','').split(','):
        #print "verificando xxx",xxx
        if xxx in SERVICEOUTPUT:
          alerta=msgs_custom[x][1]
          causas=msgs_custom[x][2]
          #restore=
          teve=1
          break
    elif not ',' in xx and xx in SERVICEOUTPUT:
      #string=
      alerta=msgs_custom[x][1]
      causas=msgs_custom[x][2]
      #restore=
      teve=1
      
  if teve==1:break
#sys.exit(1)
if teve==0:
  alerta='Nao cadastrado'
  causas='Nao cadastrado'
#Custom messages reader eof
#print 'teve',teve
#print alerta
#print causas
#sys.exit(1)

#TRADUCOES
try:
  
  #ACKNOWLEDGEMENT
  if "RECOVERY" in NOTIFICATIONTYPE:
    NOTIFICATIONTYPE="RESOLVIDO"
  else:
    NOTIFICATIONTYPE="INCIDENTE"
    
  #SAIDA DE HOST
  if "Host unreachable" in HOSTOUTPUT:
    #f=HOSTOUTPUT
    if '@' in HOSTOUTPUT:
      HOSTOUTPUT=HOSTOUTPUT.split('@')[0]
    HOSTOUTPUT=HOSTOUTPUT.replace("Host unreachable","Elemento de rede inalcan&ccedil;&aacute;vel")
      
  if "(Host Check Timed Out)" in HOSTOUTPUT:
    f=HOSTOUTPUT
    HOSTOUTPUT=HOSTOUTPUT.replace("(Host Check Timed Out)","N&atilde;o foi poss&iacute;vel contatar o elemento de rede de destino %s"%f)
  if "CRITICAL" in HOSTOUTPUT:
    HOSTOUTPUT=HOSTOUTPUT.replace('CRITICAL','CR&Iacute;TICO')

  #SAIDA DE SERVICO
  if "(Service Check Timed Out)" in SERVICEOUTPUT:
    f=SERVICEOUTPUT
    SERVICEOUTPUT=SERVICEOUTPUT.replace("(Service Check Timed Out)","N&atilde;o foi poss&iacute;vel contatar o elemento de rede de destino %s"%f)
  if "CRITICAL" in SERVICEOUTPUT:
    SERVICEOUTPUT=SERVICEOUTPUT.replace('CRITICAL','CR&Iacute;TICO')
    
    
  #escolha de assunto
  if '$' in SERVICEDESC:
    tipomensagem='host'
    #host
    if 'INCIDENTE' == NOTIFICATIONTYPE:
      subject=NOTIFICATIONTYPE+': Alerta no elemento de rede ['+HOSTNAME+']'
    else:
      subject=NOTIFICATIONTYPE+': O elemento de rede ['+HOSTNAME+'] foi restaurado'

  else:
    tipomensagem='service'
    #service
    if 'INCIDENTE' == NOTIFICATIONTYPE:
      subject=NOTIFICATIONTYPE+u': Alerta para o servi?o ['+SERVICEDESC+'] do elemento de rede ['+HOSTNAME+']'
    else:
      subject=NOTIFICATIONTYPE+u': O servi?o ['+SERVICEDESC+'] do elemento de rede ['+HOSTNAME+'] foi restaurado'
      
except Exception,e:
  print e
  usage()
  sys.exit(1)
  
#  <br><img alt="" src="data:image/gif;base64,R0lGODlhngA6APf/ALnb7+Xy+TmZ0PnavO+dTQZ/xPH4/BSGyPOxcvb6/fr8/gqBxRiIySGMy/CeT/O1eYnC4/bJnffOpvXCkfzt3/KubPXAjfS6ggJ9w/zv4fjQqu+bSWCt2n284P769hCExxyKyvS8hvGoYlqq2PCfUXK33sfi8vCiVvzq2fKvbl6s2aDO6VKm1v3z6TGVz5TJ5p3N6PnZu7DW7Priym613ffKoP759PbGmPW/i+Px+N7u9zeY0Nnr9iaQzGqz3PKsafjSrvGmXv738e72+9rs9tXp9Xm633e53/77+P727/bElP317Prgx06k1frfxYbB44XA4oG+4fjWtEGd0vfMovzs3c3l88Df8A2Dxkmi1PKrZtPo9cPg8Vao1/jVs3u74PS3fI/F5S+Uzv7480Wf0/306vGlXPCjWPCgU8vk87vc7/fPqEeg1D6c0vOzdjWXz1VVVczMzGaw24iIiAeAxe7u7hEREf/9+1mq2KrT6/bIm/nYuZnL56TQ6vvm0XW43+v1+iIiIlip2LbZ7v/8+uHw+LPY7TOWz5rL5/X6/d3d3fj7/TMzM6/W7Lu7u9Dn9Hd3d6qqqjKWz/W+iURERPGkWmZmZv3+//ncwKjS65mZmXS43vzq2vKtat3u9zyb0c7m8/bFli2TzvbGl//+/XC23azU6wN+xP3x5fn8/vGkW/3w5IzE5Prdwf3y5/S4f/v9/tHn9LTY7anT6/GnYPnYuKXR6vzr2vvo1f78+RuKyfnbvc/m9O+cS//+/vzr2/GlW6PQ6ZHG5fvp12ex2/W9iFyr2WWw29zt9+r0+vjRq4O/4iSOy/ChVPGpY/KqZbLX7aLP6fP5/L3d78nj8r/e8Pncv7fa7vrew7XZ7qvU6/3w46bR6orD467V7ODv+PrdwvD3+/nZuRmJyfvl0PS7hPnXt0+l1lOn1//9/BaHyGix2/O0d/bDk/3x5vvm0vjTr/vkzun0+nG23iWPzKfS6g+Ex/jSrfS5gPS6gUyj1a3V7CmRze+aSAB8w////yH5BAEAAP8ALAAAAACeADoAAAj/AP8JHEiwoMGDCBMqXMiwocOHDbfVuoEjFDwUuSBq3Mixo8ePD6tMUNWvZEkHYGp5eNho2ZMnUCDwAElwCxQoMJdZocmzYDaXMJ8U6fkv15oTJpOarBADScNz/qJGNUUUhtSowogSNXbVn62eVR4oHWsSgTUbBJcoq0IQz1Us04j26YpIa09iXfPwHECSrN9+CDQw8RKiU79ObAW6ldoggNyufOzylJMXpA09fzOX7KUUASHFV49onXs1smSQlK/q9cgkRWYHSDUn7RVPoCCpU8KNhnwadeWNNnax6+dgDRW/JGpokZ0UjEAW/nStA2SXtFTTvTumlrq6IKlVFFC1/yiDigKnGcpCNOsHLFSGf6TgVeCs9MGMM3/RPKBSoxMtJwIBsMIjp1kXFXbZbbRdVN0R5MoPJKhCiwiqNENfEMXs4UpBNjBRzlittOJXBX74IpAQqyQ4kIH+IKjiQwv60+BASIBDRSgWWNBOBGsM8IsQCt3RihlJAfHPDWP1gsuLB7HoIpMMxThjTwPQFwJauejhgElnKAOlQU5+CeNvdmGzGTzupPMPBeuJsAYFYhYUZpxRkqlVBPSVpMUNbgCWBJ1y8gaoQlKe1gIT4iijRD6GlaSKHk4N+g83dEmaUIxUvYhNLw7cMIkFkQ6qTVfRWIpQjDK8uMsZBEgB0Qs+5P8hTUHaoIPHCLjmmiseKnQQV0GXdCOIAF2R8cUmm5RQSiwJJbDPJiPciscxwiDDUCHRdFACsn+wwsWpXX2iAq7TCjOTQfCUM8m67LZbjAVrDEOQB0r048wuAwkhTijFsKvEHkAOBNUpAuw00BFdJSzVAiwMNRAsZCic8FcHVfNJAQrrAkEqCKXSDQgYJIxFF9YWFKPCB0SRQEGvMNcPCe0sIRA5QVDxp0ADOOPXM/iCFhUzRAzUgcQSN3DFw1ARLdUsB9lij9L+GGOAQUOMAHUPJpgMtVTnDEFQMS6X1EmKSNwMXw2abSCBz1EZM9AfW3fFTCECKZBF3H0YdAUWcYv/VpAPcfdA90AnE00MQfiEXRICKxEkhUkb0KKFM5RrUUlJGwzwz2JRjVPyIPOgc8pVknRjejesTHGVHAJdAgMN+nTFxh8l1E4DLwUZQKxU+pRAw++l6CIVHd8OBEDIndNQewl/NHHVMQTFyAErprMSBQhSFXDNQAPcAIZSbtyjzPga/JCUlwNtQ2RJJ5CDhA3wI+GFSbS4wrk/CwBAUDV0XKVCQUOTijq+QZBGdCUYC/HG6KKCAf0RRHVS+V/r0HGVTxTEEFf5wLn+ESNZECQRO7iKMWBBEGsopQYFCUFSKjCGgUggKSf4RUF2kRR43I8O0CDIIPonFUEUBG5SOUWm/wQSDEEl5AtXwUAjCvKJqzTAa//IATOusoNEECQTRowR0wYCiEOQjjoD2YNS9ECQO1wAhrcQCCnEYpIToKAgMWjODQ2hQx5GxYcEAaJU6rIiI4JLKkpk4lUWoAOBxGIcVLTiQLB4lS8Qzk5dvIrgCCLGpJBxIGZMigPeIRBCuKaNbyRIHE3SiTnW8Sp4fJsf55SQYyRxiQRp4sI8IZBHIFIqVbxiV4zwSNUQJJJSmWQYx1jGM5rEAX7o5CfZF8qBjLIkPzDlQHaIyh9Wqo+lWciCAhnLQdLyH7ZMpC6vwkuBFIqLXgzm4ARSSZNcUiCZPGYy/+FJGDZTIM/sRzSvQv8HOk7Tjv5IpUD0GBU+CoSVf2QgLAciy6gs4JvhxKUiBWKLrmyil9z5ZTqjIkx2EhOTxjzJPOsJSjgmZZ/D86dAqNlDa17FoP9A6EG2uVCBNBR/EL1lVHI5kByYQgZANYXDOAjJjfqjo/9oZ0ne+Y94ilSZ9jSpSVAalX6esqV5vOZB/TjTJHqQIG3wZi116g+e1smX6JTkOpP6UXiGlDgjXWY/3ChVaEpzpQAV6D8I6g+YytQg23zBN3hAWCK8QazgJKtZtVlUtVKyrU19KzKhWlJRnvSu/2DpHV26R4L8VWsZHAcDRjsOjM1yrOJsyDkFAkyOrlWp/WCqU+FKWWb/1lWfmNVsQDlbUM9yFbBxO21iU3vWjKZVnY+1ZDE1GdeoWnaquc0rb/vq22wSKrhROUXJIrrTiTIWraw1KlJhK1vJNreNcCIIJi7LT5VmVrpZfWl1r/NdqWCBAQfIr371C4JCDleiDlntP1p71NdCdraTpadc0RCDX+Diwbc4DnTbe9XNxrez2KTvdQEZhi2A4sMg/rAVeLEI1AJYtY1F7jCVC1Lm1rYkBIixjPOEWwr/s5oX7m2GD1Rff2AgGw7hblm9u2HjhtexK3bncuX5YtloIbo4VqV8d9yiHnOTIUJebJEZpFEke5TFbnWxghX3DChjVcoY3qp1L/XKICvW/7smEESuBLFFooJ3wOI1MJgjK2aSlgQNygAHJgZN6EHvYgZmtjCadaxmDbMZkDVVSJa9W8SrlAKjXD6ua5Or5BYzecwmAcaGFJLo3eaYulR+EmgVWpAXbAtZT1DkpMcplXLa2ch49jJb94zg85akEulNSKn1yle//rYgroR0QcRwFXWAcdaL3CWmZdRlFX+502H+tJ/7AeyFDHu6xl4zQgCn7G5KhR5QPCRx/8HIWk+7QQQe74HN++Juk9rGeI3yQLX6j0Ygj8cKCSCrzR0VMczqH9+Y4okF0u6oQOHd1d50kpe65KeC+tfBRsi3Tw1TanzgKqVSiDeSuL0HXoUFD/9jQwULAo2rnOKrt870ka29a2zzWdtytbew8f1efe+V34mImFRowAUAGP3osnBYMlwASBrMYgVQj0YPQE6QFVyFH9BQg9GvgESpiOLgMae2pgvMaYp72uLb1rnGea5bYvO73/8+RQHmTvcCYMAHA7FK3NoA9n9Io6EYqHsBFhgVbkQvxRK/ttmzjfacZ7ypd4j8HUix8UWjmiBG2NrhBlKKrTUAdwWxAvag5jeIj13evKb3xbmd8SW8ohMpSEEnbkDBq9S05ScvSOev8gKDXAIKB1Aa6x4WheBLjAzMOogJmC2xA7DiEgXhQFfqQZBkiMKJBJx4bCtO29Wr3RWXM8n/A44gCklIwgU7ONpAuLADF5hfFKUXSBjKf34XDLEgaaDBGxoAgv77Xx22NhDUUAJt4H7mJwAqkAlTkxABEAUCwH/+JwmlkAYHEQX05wIuoAYEUTX0Jwbn4BjaV15idgcIkBRq1wK0kBSvAAuL0IItCH0DcQku2IIkRBAsOIMwiBCLIA8B0IM+mAO6cRAKMIMc4xCpkAw+KA8lhhA36II5WDdEWBDkxX0J5gtgYxInmIImYQH/MAdwMAddCAdfWAeR8A+OMAd1IIZwAAlp+IUDAYZmCIcD4QhwYAmO8A9tCAd1MIeK8A+RsId0aAl9qAkCwYZn+A+QoIZ1oAiWAAd3/0iHjigQilCGeFiGiuAIeVgHhIiIdeCFYniHXggJBjGFZ9d9/2AOSQEMqEAQQqCFJeEFc2AJcRAH//CFcVAHcWAHZwgH/xAHX6gIuZiLg2gHfeiFBeGFjhAIs2gHs0gQa/gPjDAHihAIjqAJgVCLvMiMxqgIXkiLjKAJyRgHXhgJ1/gPlsAIAjEH6JiIwUiLYvgPzEiGzPgPmkAJcZCIUjhvYvYPLaAzJ/EKOLAuOHABJGASZoAK8ygQcBAIgYCLdmAJ+FiLYJiL7/gPlAAJomiMBGGMtmgHgSCH0GgHmvCQGsmMYjgH2siLYdiLdqCQczAHgfCMdcAIcFCGliCSdv/ACLn4kdiIkrSYiy7JkvmYevv4DwOwAczhBdBIiRIpEMJIk0GZi8YYCXYAB3bQiSr5hrzICJEAlAQxjZQQk4EQCehYB1f5hT6pkcZolnvIlZ4IhpAQCIyAjmIZll4pkT4plIgoimQ5lDbXawThC2ijGTdwB35YlbwIBzQ5B0AZCZYQlS1JCZpgi5bwkjF5h+kYk49JkXooEJFgjw3ZkJRACYwgim5oj2qpkpDACKMZhnUQCNPoCHGgk6EZB5SAkmKYhmBoj3o5jQvJlALxOEmhBGX0PUlRGwVRC/6oFBvwDOZAELgoELh4i//Qh9A5ENa5iAOxh81IEHFgnb3YndJniZ1OmZ0FsYfjKYm0OJ57aJ7gyZ3NiJ5f6Z3yORDDEAqhMAqjoAQAMhCkUAsToJ9KoAcpYhBJsAs1kJ/6WQOt0EKm8qA9IQQowAkUigJlUBCoMAwVeguNYxBCkAEUygm3sApoQRABAQA7" />

if '-Alarmes-' in HOSTNAME:
  #if 'INCIDENTE' ==NOTIFICATIONTYPE:
  subject=HOSTNAME+" : "+SERVICEOUTPUT.replace('Alarme:','')
  #else:
    #subject=HOSTNAME+" : "+SERVICEOUTPUT
    
  text="""<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
  <body style="word-wrap: break-word; -webkit-nbsp-mode: space; -webkit-line-break: after-white-space; ">
  <div><span>
<b><font size="4">Execute as a&ccedil;&otilde;es abaixo:</font></b>&nbsp;<br> <br>"""+LONGSERVICEOUTPUT.split('check:')[0].replace('\\n','<br>')
  if 'check:' in LONGSERVICEOUTPUT:
    text+="""<br><br><b><font size="4">Data da gera&ccedil;&atilde;o do alarme:</font></b>&nbsp;"""+LONGSERVICEOUTPUT.split('check:')[1].split('div style')[0]
  text+="""<br></body></html>"""
  
  subject="[%s] %s"%(cliente,subject)  
  mail(IPSMTPSRV, USERMAIL, SENHAMAIL,subject,text,tlsvar,to)
  sys.exit(0)
    
    
try:
  if tipomensagem=='service':
    #if '<br>' in COMBO:
    #  s=''
    #  for x in COMBO.split('<br>'):
    #    if len(x)==10:
    #      s+=datetime.datetime.fromtimestamp(int(x)).strftime('%Y-%m-%d %H:%M:%S')
    #    else:
    #      s+=x
    #    s+='<br>'
    #  COMBO=s      
    if 'DOWN' == HOSTSTATE:sys.exit(0)#se o host tiver fora nao notifica servicos
    #text    
    filename_log='%s%s_%s_incidente'.replace(' ','_')%(pluginspath,HOSTNAME,SERVICEDESC)
    #print filename_log,NOTIFICATIONTYPE,LASTSERVICECHECK
    if NOTIFICATIONTYPE=='INCIDENTE':#com problema
      
      #print filename_log,NOTIFICATIONTYPE,LASTSERVICECHECK

      if not os.path.isfile(filename_log):open(filename_log,'w').write(LASTSERVICECHECK)
      
      #sys.exit(1)
      text="""<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
              <body style="word-wrap: break-word; -webkit-nbsp-mode: space; -webkit-line-break: after-white-space; ">
              <div><span>
              <b><font size="4">Tipo do Alerta:</font></b>"""+NOTIFICATIONTYPE+"""
              <br><br><br>
              <b><font size="4">Servi&ccedil;o:</font></b>
              <br><br>
              <b><i>Alerta identificado:</i><font size=3D"4">&nbsp;</font></b>"""+alerta+"""</div>
              <b><i>Possiveis causas:</i><font size=3D"4">&nbsp;</font></b>"""+causas+"""</div>
              <b><i>Mensagem tecnica do servi&ccedil;o:</i><font size=3D"4">&nbsp;</font></b><<<i>"""+SERVICEOUTPUT+"""</i>>></div>
              <div><b><i>Nome do servi&ccedil;o com problema</i>:&nbsp;</b>"""+SERVICEDESC+"""</div><div>
              <br></div><div><br></div>
              <div><b><font size="4">Este servi&ccedil;o pertence ao elemento:</font></b>
              <br><br><b><i>Nome do elemento de rede:</i></b> """+HOSTNAME+"""&nbsp;</div>
              <div><b><i>Endere&ccedil;o IP: </i></b>"""+HOSTADDRESS+"""&nbsp;</div>
              <div><b><i>Status:</i></b>"""+HOSTSTATE+""" &nbsp; &nbsp;</div>
              <div><b><i>Desempenho do elemento:&nbsp;</i></b>"""+HOSTOUTPUT+"""</div>
              </span></div>
              <br>
              <br></body></html>"""
    else:
        #resolvido
      #print filename_log,NOTIFICATIONTYPE,LASTSERVICECHECK

      start_time=open(filename_log,'r').read()
      end_time=LASTSERVICECHECK
      tf=seconds_to_dhms(int(end_time)-int(start_time))
      #tempofora="%d dia(s) %d hora(s) %d minuto(s) %s segundo(s)"
      tempofora=''      
      if tf[0]>0:tempofora+="%d dia(s) "%tf[0]
      if tf[1]>0:tempofora+="%d hora(s) "%tf[1]
      if tf[2]>0:tempofora+="%d minuto(s) "%tf[2]
      if tf[3]>0:tempofora+="%d segundo(s) "%tf[3]
        
      text="""<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
        <body style="word-wrap: break-word; -webkit-nbsp-mode: space; -webkit-line-break: after-white-space; ">
        <div><span>
        <b><font size="4">Tipo do Alerta:</font></b>&nbsp;"""+NOTIFICATIONTYPE+"""
        <br><br><br>
        <b><font size="4">Servi&ccedil;o:</font></b>
        <br><br><b>
        <i>Aviso de retorno:</i><font size=3D"4">&nbsp;</font></b><<<i>"""+SERVICEOUTPUT+"""</i>>></div>
        <div><b><i>Nome do servi&ccedil;o restaurado:</i>&nbsp;</b>"""+SERVICEDESC+"""</div><div>
        <br></div><div><br></div>
        <div><b><font size="4">Este servi&ccedil;o pertence ao elemento:</font></b>
        <br><br><b><i>Nome do elemento de rede:</i></b> """+HOSTNAME+"""&nbsp;</div>
        <div><b><i>Endere&ccedil;o IP: </i></b>"""+HOSTADDRESS+"""&nbsp;</div>
        <div><b><i>Status:</i></b>"""+HOSTSTATE+""" &nbsp; &nbsp;</div>
        <div><b><i>Desempenho do elemento:&nbsp;</i></b>"""+HOSTOUTPUT+"""</div>
        <div><b><i>Tempo fora:&nbsp;</i></b>"""+tempofora+"""
        </span></div>
        <br>
        <br></body></html>"""
# 
      if os.path.isfile(filename_log):os.remove(filename_log)
    
  else:
    if NOTIFICATIONTYPE=='INCIDENTE':#com problema
      text="""<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
  <body style="word-wrap: break-word; -webkit-nbsp-mode: space; -webkit-line-break: after-white-space; ">
  <div><span>
  <b><font size="4">Tipo do Alerta:</font></b>&nbsp;"""+NOTIFICATIONTYPE+"""
  <br><br><br>
  <b><i>Alerta identificado:</i></b><font size="4">&nbsp;</font></b><<<i>"""+HOSTOUTPUT+"""</i>>></div>
  <br></div><div><br></div>
  <div><b><font size="4">Elemento de rede impactado:</font></b>
  <br><br><b><i>Nome do elemento de rede:</i></b> """+HOSTNAME+"""&nbsp;</div>
  <div><b><i>Endere&ccedil;o IP: </i></b>"""+HOSTADDRESS+"""&nbsp;</div>
  <div><b><i>Status:</i></b>"""+HOSTSTATE+""" &nbsp; &nbsp;</div>
  </span></div>
  <br>
  <br></body></html>"""
    else:#resolvido
      text="""<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
  <body style="word-wrap: break-word; -webkit-nbsp-mode: space; -webkit-line-break: after-white-space; ">
  <div><span>
  <b><font size="4">Tipo do Alerta:</font></b>&nbsp;"""+NOTIFICATIONTYPE+"""
  <br><br><br>
  <b><i>Aviso de retorno:</i></b><font size="4">&nbsp;</font></b><<<i>"""+HOSTOUTPUT+"""</i>>></div>
  <br></div><div><br></div>
  <div><b><font size="4">Elemento de rede que foi impactado:</font></b>
  <br><br><b><i>Nome do elemento de rede:</i></b> """+HOSTNAME+"""&nbsp;</div>
  <div><b><i>Endere&ccedil;o IP: </i></b>"""+HOSTADDRESS+"""&nbsp;</div>
  <div><b><i>Status:</i></b>"""+HOSTSTATE+""" &nbsp; &nbsp;</div>
  </span></div>
  <br>
  <br></body></html>"""
      
      
  #text="\
  #Tipo:"+NOTIFICATIONTYPE+"
  #Host: "+HOSTNAME+"
  #Descricao de Servico:"+SERVICEDESC+"\n\
  #Status do Host: "+HOSTSTATE+"\n\
  #"+SERVICESTATE+"\n\
  #Address: "+HOSTADDRESS+"\n\
  #Info: "+HOSTOUTPUT+"\n\
  #"+SERVICEOUTPUT

  #text="""
  #Tipo:"""+NOTIFICATIONTYPE+"""

  #Hostname: """+HOSTNAME+""" IP: """+HOSTADDRESS+""" status:"""+HOSTSTATE+"""
  #Ping: """+HOSTOUTPUT+"""

  #Service Name:"""+SERVICEDESC+"""
  #Status do Servico:"""+SERVICESTATE+"""
  #Mensagem do Plugin:
  #"""+SERVICEOUTPUT+"""
#"""
  #print subject
  #print text
except Exception,e:
  print e
  usage()
  sys.exit(1)
  
#192.168.0.70_InfoCRITICAL-HostUnreachable192.168.0.70
#nao =0
#try:
  #nomefiletmp='/var/lib/centreon/centplugins/alert_%s_%s_%s' %(HOSTADDRESS,SERVICEDESC,HOSTSTATE)
  #nomefiletmp = nomefiletmp.replace(')','').replace('(','').replace(':','').replace(' ','_').replace('$','1')
  #tempo = open(nomefiletmp,'r').read()
  #atual = datetime.datetime(int(tempo.split()[0].split("-")[0]),\
                            #int(tempo.split()[0].split("-")[1]),\
                            #int(tempo.split()[0].split("-")[2]),\
                            #int(tempo.split()[1].split(":")[0]),\
                            #int(tempo.split()[1].split(":")[1]),\
                            #int(tempo.split()[1].split(":")[2].split(".")[0]),\
                            #int(tempo.split()[1].split(":")[2].split(".")[1]))


  #resultado = atual-datetime.datetime.now() + datetime.timedelta(days=1)
  #if ''.join(str(resultado)).count("-7 day"):
    ##print 'passou uma semana'
    #os.system('echo "passou uma semana %s ">> /tmp/lognotfy.log' % ''.join(str(resultado)))
    #os.system('echo removendo %s >> /tmp/lognotfy.log' % nomefiletmp)
    #os.system('rm -rf %s' % nomefiletmp)
  #else:
    ##print 'nao passou uma semana'
    #os.system('echo nao passou uma semana %s >> /tmp/lognotfy.log' % HOSTNAME)

    #nao=1
#except Exception,e:
  ##print 'nao existe criando.'
  #os.system('echo nao existe criando %s >> /tmp/lognotfy.log' % e)

  #nao=0
  #timeatual=''.join(str(datetime.datetime.now()))
  #open(nomefiletmp,'w').write(timeatual)

#if nao==0:
subject="[%s] %s"%(cliente,subject)
mail(IPSMTPSRV, USERMAIL, SENHAMAIL,subject,text,tlsvar,to)

  #print 'Email enviado'
  #os.system('echo Email enviado %s >> /tmp/lognotfy.log' % HOSTNAME)

#else:
  ##print 'nao enviar'
  #os.system('echo nao enviar >> /tmp/lognotfy.log')

  
  
  